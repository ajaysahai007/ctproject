(this["webpackJsonpneed-a-web-developer-21043817"] = this["webpackJsonpneed-a-web-developer-21043817"] || []).push([["main"],{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/scss/main.css":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!./node_modules/postcss-loader/src??postcss!./src/scss/main.css ***!
  \******************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
exports.push([module.i, "@import url(https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap);"]);
// Module
exports.push([module.i, "body {\n  left: 0;\n  top: 0;\n  margin: 0;\n  padding: 0;\n  overflow-x: hidden;\n  font-family: \"Saira Semi Condensed\", sans-serif;\n}\n\n.buttonThemeHange {\n  position: fixed !important;\n  bottom: 55px;\n  z-index: 9999;\n  left: 6px;\n}\n\n.buttonThemeHange11 {\n  display: flex;\n  justify-content: space-between;\n}\n\n.heading1 {\n  color: #0d8ccd;\n  font-size: 16px;\n  background-color: #000;\n  display: flex;\n  justify-content: center;\n}\n\n.textbox h1 {\n  color: red;\n}\n\n.textbox h1:hover {\n  color: black;\n}\n\n.d-flex {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.d-flex.justify-space-between {\n  justify-content: space-between;\n}\n\n.d-flex.justify-start {\n  justify-content: flex-start;\n}\n\n.d-flex.alignstart {\n  align-items: flex-start !important;\n}\n\n.d-flex.justify-end {\n  justify-content: flex-end;\n}\n\n.height100 {\n  height: 100%;\n}\n\n.padding10 {\n  padding: 10px 0;\n}\n\n.extra-bold {\n  font-weight: 700 !important;\n}\n\n.coin_list .MuiTypography-body2 span {\n  font-size: 17px;\n  font-weight: 600;\n}\n\n.coin_list .MuiTypography-body1 span {\n  font-size: 13px;\n  font-weight: 300;\n}\n\n.d-flex {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.d-flex.justify-space-between {\n  justify-content: space-between;\n}\n\n.d-flex.justify-start {\n  justify-content: flex-start;\n}\n\n.d-flex.alignstart {\n  align-items: flex-start !important;\n}\n\n.d-flex.justify-end {\n  justify-content: flex-end;\n}\n\n.step_bar {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n  box-shadow: 0 0.1rem 0.7rem rgba(0, 0, 0, 0.1);\n}\n\n.completed h5,\n.activeStep h5 {\n  text-align: center;\n  font-size: 15px;\n  justify-content: center;\n  align-items: center;\n  color: #31335d;\n}\n\n.completed {\n  height: 50px;\n  width: 50px;\n  border: 3px solid #5a86ff;\n  border-radius: 50%;\n  margin: 0 15px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  position: relative;\n  background-color: #fff;\n}\n\n.activeStep {\n  height: 50px;\n  width: 50px;\n  border: 3px solid #dfdfdf;\n  border-radius: 50%;\n  margin: 0 15px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  position: relative;\n  background-color: #fff;\n  z-index: 999;\n}\n\n.left-nav .MuiButton-label {\n  display: flex;\n  flex-direction: column;\n}\n\n.page-heading {\n  font-weight: 300 !important;\n  font-size: 36px !important;\n  line-height: 54px;\n}\n\n.page-heading2 {\n  font-weight: 400 !important;\n  font-size: 30px !important;\n}\n\n.text-white {\n  color: #fff;\n}\n\n.customForm {\n  max-width: 100%;\n  margin: 0 auto;\n  border-radius: 5px;\n}\n\n.customForm.MuiTextField-root {\n  margin: 20px 0;\n}\n\n.customFormh5 {\n  margin: 10px 0;\n}\n\n.rightButton {\n  float: right;\n}\n\n.leftButton {\n  float: left;\n}\n\n.dzu-dropzone {\n  overflow: auto !important;\n}\n\n.rightPosition {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n  right: 20px;\n}\n\n.notication-list a {\n  color: #000;\n}\n\n.width120 {\n  width: calc(100% - 150px);\n}\n\n.ellispsys {\n  text-overflow: ellipsis;\n  overflow: hidden;\n  display: block;\n  white-space: pre;\n  width: calc(100% - 30px);\n}\n\n.row-reverse {\n  flex-direction: row-reverse;\n  margin-left: -38px;\n}\n\n.orderlist {\n  order: 0;\n}\n\n@media screen and (max-width: 768px) {\n  .orderlist {\n    order: 1;\n  }\n  .row-reverse {\n    margin-left: 0px;\n    margin-bottom: 20px;\n  }\n  .activeStep {\n    height: 35px;\n    width: 35px;\n    border: 3px solid #dfdfdf;\n  }\n  .completed {\n    height: 35px;\n    width: 35px;\n  }\n  .step_bar {\n    width: 100%;\n    display: flex;\n    flex-direction: column;\n    justify-content: space-around;\n    box-shadow: 0 0.1rem 0.7rem rgba(0, 0, 0, 0.1);\n  }\n  .width120 {\n    width: 100%;\n    margin-bottom: 20px;\n  }\n  .rightPosition {\n    position: absolute;\n    top: auto;\n    bottom: -5px;\n    right: auto;\n    left: 55px;\n  }\n}\n\n.side_nev_Bottom {\n  position: absolute;\n  bottom: 0;\n  width: 100%;\n}\n\n.loginForm {\n  width: 90%;\n  max-width: 600px;\n  margin-bottom: 20px;\n  -webkit-backdrop-filter: blur(5px);\n          backdrop-filter: blur(5px);\n  background-color: transparent;\n}\n\n.fullwidth {\n  width: 100%;\n}\n\n.faqBg {\n  height: 150px;\n  background: url(\"https://dummyimage.com/600x400/00ab99/00ab99\");\n  border-radius: 12px;\n}\n\n.kycCard {\n  border: 1px solid #e46a761f;\n  background-color: #fff;\n  padding: 15px;\n  transition: all 0.3s ease-in-out;\n  transform: translateY(0px);\n}\n\n.kycCard:hover {\n  transform: translateY(-5px);\n  transition: all 0.3s ease-in-out;\n}\n\n.boxCard {\n  transition: box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n  background-image: none;\n  overflow: hidden;\n  border-radius: 16px;\n  position: relative;\n  z-index: 0;\n  box-shadow: none;\n  text-align: center;\n  padding: 40px 0px;\n  box-shadow: rgba(90, 114, 123, 0.11) 0px 7px 30px 0px;\n}\n\n.boxCard .iconBox {\n  margin: auto auto 24px;\n  display: flex;\n  border-radius: 50%;\n  align-items: center;\n  width: 64px;\n  height: 64px;\n  justify-content: center;\n}\n\n.greenicon {\n  color: #007b55;\n  background-image: linear-gradient(135deg, rgba(0, 123, 85, 0) 0%, rgba(0, 123, 85, 0.24) 100%);\n}\n\n.green {\n  color: #005249;\n  background-color: #c8facd;\n}\n\n.blueicon {\n  color: #0c53b7;\n  background-image: linear-gradient(135deg, rgba(12, 83, 183, 0) 0%, rgba(12, 83, 183, 0.24) 100%);\n}\n\n.blue {\n  color: #dfdfdf;\n  background-color: #31335d;\n}\n\n.gray {\n  background: #b7c3d587;\n}\n\n.yellowicon {\n  color: #b78103;\n  background-image: linear-gradient(135deg, rgba(183, 129, 3, 0) 0%, rgba(183, 129, 3, 0.24) 100%);\n}\n\n.yellow {\n  color: #7a4f01;\n  background-color: #fff7cd;\n}\n\n.redicon {\n  color: #b72136;\n  background-image: linear-gradient(135deg, rgba(183, 33, 54, 0) 0%, rgba(183, 33, 54, 0.24) 100%);\n}\n\n.red {\n  color: #7a0c2e;\n  background-color: #ffe7d9;\n}\n\n.mixed-chart2 {\n  height: 400px;\n}\n\n.userslist {\n  background-color: #e0e0e0;\n  border-radius: 4px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 10px;\n  padding: 7px;\n  margin-right: 6px;\n}\n\n.userslist a {\n  font-size: 13px;\n  font-weight: 600;\n  margin-right: 10px;\n  text-decoration: none;\n}\n\n.bgWhite {\n  background-color: #fff;\n}\n\n.CircularProgressbar .CircularProgressbar-text {\n  fill: red;\n  font-size: 20px;\n  text-anchor: middle;\n}\n\n.CircularProgressbar .CircularProgressbar-path {\n  stroke: #dfdfdf !important;\n  stroke-linecap: round;\n  transition: stroke-dashoffset 0.5s ease 0s;\n}\n\n.TabButtonsBox1 {\n  width: -moz-fit-content;\n  width: fit-content;\n  border-bottom: 1px solid #1eb808;\n  /* margin-bottom: 30px; */\n  padding-bottom: 10px;\n}\n\n.TabButtonsBox1 button.active {\n  background-color: #1eb808;\n  color: #fff;\n}\n\n.TabButtonsBox1 button {\n  border: 1px solid #1eb808;\n  font-size: 16px;\n  font-weight: 600;\n  margin-right: 15px;\n  padding: 6px 20px;\n  border-radius: 4px;\n  margin-top: 10px;\n}\n\n.TabButtonsBox button.active {\n  background-color: initial;\n  border-bottom: 2px solid #1eb808;\n  border-radius: 0 !important;\n  padding: 10px 3px;\n  color: #1eb808;\n  font-weight: 600 !important;\n  font-size: 16px;\n  line-height: 22px;\n}\n\n.boxLine {\n  border-bottom: 0.5px solid #3f3f3f;\n}\n\n.TabButtonsBox button {\n  font-weight: 600 !important;\n  font-size: 16px;\n  line-height: 22px;\n  border-radius: 5px;\n  padding: 10px 3px;\n  margin-right: 14px;\n  color: #fff;\n}\n\n.MuiButton-text {\n  padding: 6px 8px;\n  font-family: \"Saira Semi Condensed\", sans-serif;\n}\n\n.headingText {\n  font-size: 50px;\n  color: #01fbb4 !important;\n  filter: drop-shadow(0 0 10px #1eb808);\n  text-align: center;\n}\n\n.loginBox {\n  display: flex;\n  justify-content: center;\n  height: 100%;\n  align-items: center;\n}\n\n.moveTop {\n  animation: moveTop 5s normal linear infinite;\n}\n\n@keyframes moveTop {\n  0% {\n    transform: translateY(0);\n  }\n  50% {\n    transform: translateY(-20px);\n  }\n  100% {\n    transform: translateY(0px);\n  }\n}\n\n.moveLeft {\n  animation: moveLeft 5s normal linear infinite;\n}\n\n@keyframes moveLeft {\n  0% {\n    transform: translateX(0);\n  }\n  50% {\n    transform: translateX(-20px);\n  }\n  100% {\n    transform: translateX(0px);\n  }\n}\n\n.jodit,\n.jodit *,\n.jodit-container,\n.jodit-container * {\n  color: white;\n  box-sizing: border-box;\n}\n\n.jodit-wysiwyg {\n  min-height: 220px !important;\n}\n\n.filterBox {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.deleteText {\n  font-size: 20px;\n  font-size: 30px;\n  color: #fff;\n  text-align: center;\n  font-size: 25px !important;\n}\n\n::-webkit-scrollbar {\n  display: none;\n}\n\n.stakeButoon {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.Component-paper-28 {\n  border: 1px solid #3b5c7d;\n}\n\nli.menutext {\n  padding-left: 10px;\n}\n\nli.menutext a {\n  font-size: 14px;\n  text-decoration: none;\n  color: #707070;\n}\n\nselect.selectBox {\n  border: none !important;\n  background: transparent;\n  color: #55595e;\n}\n\nselect.selectBox:focus-visible {\n  outline: none;\n}\n\n.mainBoxfilter {\n  display: flex;\n  flex-wrap: wrap;\n  margin-bottom: 10px;\n  border: 1px solid #e0e0e0;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.mainBoxfilter div {\n  padding: 20px;\n  border-right: 0.1px solid #e0e0e0;\n}\n\n.mainBoxfilter div:last-child {\n  border-right: none;\n}\n\n.mainBoxfilter4 {\n  color: #52565c;\n  font-size: 14px;\n  width: 22%;\n}\n\n.searchBar {\n  display: flex;\n  align-items: center;\n  padding: 0px 20px !important;\n  width: 23%;\n}\n\n.searchBar svg {\n  height: 42px;\n  border-left: 0;\n  padding: 0 5px;\n}\n\n.searchBar input {\n  height: 40px;\n  width: 100%;\n  padding-left: 10px;\n  height: 40px;\n  font-size: 11px;\n  border: 1px solid #e0e0e0;\n}\n\n.searchBar input:focus-visible {\n  outline: none;\n}\n\n.orderlist {\n  background-color: #fff;\n}\n\n.blue {\n  background-color: #b0c0ed;\n  color: #122a6c;\n}\n\n.maintable {\n  width: 100%;\n}\n\n@media (max-width: 1366px) {\n  .maintable {\n    width: 1050px !important;\n  }\n}\n\ninput[type=\"number\"]::-webkit-inner-spin-button,\ninput[type=\"number\"]::-webkit-outer-spin-button {\n  -webkit-appearance: none;\n  appearance: none;\n  margin: 0;\n}\n\n@media (max-width: 1366px) {\n  .first-table {\n    min-width: 250px;\n  }\n}\n\n@media (max-width: 1024px) {\n  .mainBoxfilter4 {\n    width: 16%;\n  }\n  .mainBoxfilter div {\n    padding: 10px;\n    width: 30.33%;\n    margin: 0;\n    border-bottom: 0.1px solid #e0e0e0;\n  }\n  .tableToken {\n    min-width: 100px !important;\n  }\n}\n\n@media (max-width: 991px) {\n  .loginForm {\n    width: 100%;\n    max-width: 100%;\n  }\n  .height100 {\n    height: 75%;\n  }\n  .table-data-first {\n    min-width: 180px;\n  }\n}\n\n@media (max-width: 767px) {\n  .loginForm h2 {\n    font-size: 25px;\n  }\n  .height100 {\n    height: 75%;\n  }\n  .headingText {\n    font-size: 17px !important;\n  }\n}\n\n@media (max-width: 600px) {\n  .height100 {\n    height: 75%;\n  }\n}", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./src/APIconfig/ApiConfig.js":
/*!************************************!*\
  !*** ./src/APIconfig/ApiConfig.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
let baseurl = "http://172.16.1.172:1884"; // let baseurl = 'https://blockchain-tool.mobiloitte.com'

let user = `${baseurl}/api/v1/user`;
let admin = `${baseurl}/api/v1/admin`;
let contract = `${baseurl}/api/v1/contract`;
const apiConfig = {
  //USER
  login: `${user}/login`,
  register: `${user}/register`,
  profile: `${user}/profile`,
  addToken: `${user}/addToken`,
  tokenList: `${user}/tokenList`,
  resetPassword: `${user}/resetPassword`,
  //CHANDRA
  forgotPassword: `${user}/forgotPassword`,
  // SubAdmin
  //ADMIN
  addSubAdmin: `${admin}/addSubAdmin`,
  listSubAdmin: `${admin}/listSubAdmin`,
  deleteSubAdmin: `${admin}/deleteSubAdmin?subAdminId=`,
  editSubAdmin: `${admin}/editSubAdmin`,
  viewSubAdmin: `${admin}/viewSubAdmin`,
  // login: `${admin}/login`,
  //CONTRACT
  getPolygonContractDetails: `${contract}/getPolygonContractDetails`
};
/* harmony default export */ __webpack_exports__["default"] = (apiConfig);

/***/ }),

/***/ "./src/App.js":
/*!********************!*\
  !*** ./src/App.js ***!
  \********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/pickers */ "./node_modules/@material-ui/pickers/esm/index.js");
/* harmony import */ var _date_io_moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @date-io/moment */ "./node_modules/@date-io/moment/build/index.esm.js");
/* harmony import */ var src_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/routes */ "./src/routes.js");
/* harmony import */ var history__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! history */ "./node_modules/history/esm/history.js");
/* harmony import */ var src_context_Auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/context/Auth */ "./src/context/Auth.js");
/* harmony import */ var src_component_PageLoading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/component/PageLoading */ "./src/component/PageLoading.js");
/* harmony import */ var src_context_SettingsContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/context/SettingsContext */ "./src/context/SettingsContext.js");
/* harmony import */ var src_component_AuthGuard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/component/AuthGuard */ "./src/component/AuthGuard.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var src_theme__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/theme */ "./src/theme/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/App.js";












const history = Object(history__WEBPACK_IMPORTED_MODULE_5__["createBrowserHistory"])();

function App() {
  const themeSeeting = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(src_context_SettingsContext__WEBPACK_IMPORTED_MODULE_8__["default"]);
  const theme = Object(src_theme__WEBPACK_IMPORTED_MODULE_11__["createTheme"])({
    theme: themeSeeting.settings.theme
  });
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "App",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_10__["ThemeProvider"], {
    theme: theme,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_2__["MuiPickersUtilsProvider"], {
    utils: _date_io_moment__WEBPACK_IMPORTED_MODULE_3__["default"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(src_context_Auth__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Router"], {
    history: history,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(RenderRoutes, {
    data: src_routes__WEBPACK_IMPORTED_MODULE_4__["routes"],
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 15
    }
  }))))));
}

/* harmony default export */ __webpack_exports__["default"] = (App);

function RenderRoutes(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0__["Suspense"], {
    fallback: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(src_component_PageLoading__WEBPACK_IMPORTED_MODULE_7__["default"], {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 25
      }
    }),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Switch"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }
  }, props.data.map((route, i) => {
    const Component = route.component;
    const Guard = route.guard ? src_component_AuthGuard__WEBPACK_IMPORTED_MODULE_9__["default"] : react__WEBPACK_IMPORTED_MODULE_0__["Fragment"];
    const Layout = route.layout || react__WEBPACK_IMPORTED_MODULE_0__["Fragment"];
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
      exact: route.exact,
      key: i,
      path: route.path,
      render: props => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Guard, {
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 17
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Layout, {
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 19
        }
      }, route.routes ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(RenderRoutes, {
        data: route.routes,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 23
        }
      }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Component, Object.assign({}, props, {
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 23
        }
      })))),
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 13
      }
    });
  })));
}

/***/ }),

/***/ "./src/component/AuthGuard.js":
/*!************************************!*\
  !*** ./src/component/AuthGuard.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AuthGuard; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var src_context_Auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/context/Auth */ "./src/context/Auth.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/component/AuthGuard.js";



function AuthGuard(props) {
  const {
    children
  } = props;
  const auth = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(src_context_Auth__WEBPACK_IMPORTED_MODULE_2__["AuthContext"]);

  if (!auth.userLoggedIn) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Redirect"], {
      to: "/",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 12
      }
    });
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, children);
}

/***/ }),

/***/ "./src/component/Logo.js":
/*!*******************************!*\
  !*** ./src/component/Logo.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/component/Logo.js";



const Logo = props => {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Box"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("img", Object.assign({
    src: "/images/logo.png",
    alt: "Logo"
  }, props, {
    width: "auto",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (Logo);

/***/ }),

/***/ "./src/component/PageLoading.js":
/*!**************************************!*\
  !*** ./src/component/PageLoading.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PageLoading; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/component/PageLoading.js";


const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["makeStyles"])(theme => ({
  root: {
    alignItems: "center",
    backgroundColor: "#000",
    display: "flex",
    flexDirection: "column",
    height: "100%",
    justifyContent: "center",
    left: 0,
    padding: theme.spacing(3),
    position: "fixed",
    top: 0,
    width: "100%",
    zIndex: 2000
  },
  loader: {
    width: 300,
    maxWidth: "100%",
    margin: "auto"
  },
  progressBar: {
    height: "3px"
  }
}));
function PageLoading() {
  const classes = useStyles();
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.root,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    width: 300,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    className: classes.loader,
    src: "/images/logo.png",
    alt: "loader",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 9
    }
  })));
}

/***/ }),

/***/ "./src/constants/index.js":
/*!********************************!*\
  !*** ./src/constants/index.js ***!
  \********************************/
/*! exports provided: NetworkContextName, ACTIVE_NETWORK, tokenContract, MarketplaceContract, NftTokenAddress */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NetworkContextName", function() { return NetworkContextName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ACTIVE_NETWORK", function() { return ACTIVE_NETWORK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tokenContract", function() { return tokenContract; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MarketplaceContract", function() { return MarketplaceContract; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NftTokenAddress", function() { return NftTokenAddress; });
const NetworkContextName = "NETWORK";
const ACTIVE_NETWORK = 42;
const tokenContract = "0xE4861c8C1A80250e1e280F7F7bbf84736146b867";
const MarketplaceContract = "0xf5DE7F4Ee0C4063a1e6f139fEa2eB92c2D153653";
const NftTokenAddress = "0x4846666e4013A48647be98AF3FDE33251e679bd2";

/***/ }),

/***/ "./src/context/Auth.js":
/*!*****************************!*\
  !*** ./src/context/Auth.js ***!
  \*****************************/
/*! exports provided: AuthContext, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthContext", function() { return AuthContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return AuthProvider; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_APIconfig_ApiConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/APIconfig/ApiConfig */ "./src/APIconfig/ApiConfig.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/context/Auth.js";





const AuthContext = Object(react__WEBPACK_IMPORTED_MODULE_0__["createContext"])();

const setSession = accessToken => {
  if (accessToken) {
    localStorage.setItem('creatturAccessToken', accessToken);
    axios__WEBPACK_IMPORTED_MODULE_1___default.a.defaults.headers.common.Authorization = `Bearer ${accessToken}`;
  } else {
    localStorage.removeItem('creatturAccessToken');
    delete axios__WEBPACK_IMPORTED_MODULE_1___default.a.defaults.headers.common.Authorization;
  }
};

function checkLogin() {
  const accessToken = window.sessionStorage.getItem('token');
  return accessToken ? true : false;
}

function AuthProvider(props) {
  const [isLogin, setIsLogin] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(checkLogin());
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_4__["useHistory"])();
  const [userData, setUserData] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({});
  const [searchToken, setSearchToken] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])('');
  const [theme, setTheme] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
  const token = window.sessionStorage.getItem('token');

  const getProfileHandler = async accessToken => {
    try {
      const res = await axios__WEBPACK_IMPORTED_MODULE_1___default()({
        method: 'GET',
        url: src_APIconfig_ApiConfig__WEBPACK_IMPORTED_MODULE_2__["default"].profile,
        headers: {
          token: accessToken
        }
      });

      if (res.data.responseCode === 200) {
        setUserData(res.data.result);
      }
    } catch (error) {
      console.log(error);
    }
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (token) {
      getProfileHandler(token);
    }
  }, [window.sessionStorage.getItem('token')]);

  const getPolygonContractDetailsHandler = async searchKey => {
    try {
      const res = await axios__WEBPACK_IMPORTED_MODULE_1___default()({
        method: 'GET',
        url: src_APIconfig_ApiConfig__WEBPACK_IMPORTED_MODULE_2__["default"].getPolygonContractDetails,
        headers: {
          token: token
        },
        params: {
          contractAddress: searchKey
        }
      });

      if (res.data.responseCode === 200) {
        console.log('finalDAta*****', res.data.result);
      }
    } catch (error) {
      console.log(error);
    }
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (searchToken !== '') {
      if (token) {
        getPolygonContractDetailsHandler(searchToken);
      } else {
        react_toastify__WEBPACK_IMPORTED_MODULE_3__["toast"].warn('Please login first!!');
      }
    }
  }, [searchToken, token]);
  let data = {
    userLoggedIn: isLogin,
    userData,
    searchToken,
    theme,
    setTheme: data => setTheme(data),
    setSearchToken: data => setSearchToken(data),
    userLogIn: (type, data) => {
      setSession(data);
      setIsLogin(type);
    },
    getProfileHandler: data => getProfileHandler(data)
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(AuthContext.Provider, {
    value: data,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 97,
      columnNumber: 5
    }
  }, props.children);
}

/***/ }),

/***/ "./src/context/SettingsContext.js":
/*!****************************************!*\
  !*** ./src/context/SettingsContext.js ***!
  \****************************************/
/*! exports provided: restoreSettings, storeSettings, SettingsProvider, SettingsConsumer, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "restoreSettings", function() { return restoreSettings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storeSettings", function() { return storeSettings; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsProvider", function() { return SettingsProvider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsConsumer", function() { return SettingsConsumer; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/context/SettingsContext.js";


const defaultSettings = {
  direction: "ltr",
  responsiveFontSizes: true,
  theme: "DARK"
};
const restoreSettings = () => {
  let settings = null;

  try {
    const storedData = window.localStorage.getItem('settings');

    if (storedData) {
      settings = JSON.parse(storedData);
    }
  } catch (err) {
    console.error(err); // If stored data is not a strigified JSON this will fail,
    // that's why we catch the error
  }

  return settings;
};
const storeSettings = settings => {
  window.localStorage.setItem('settings', JSON.stringify(settings));
};
const SettingsContext = Object(react__WEBPACK_IMPORTED_MODULE_0__["createContext"])({
  settings: defaultSettings,
  saveSettings: () => {}
});
const SettingsProvider = ({
  settings,
  children
}) => {
  const [currentSettings, setCurrentSettings] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(settings || defaultSettings);

  const handleSaveSettings = (update = {}) => {
    const mergedSettings = lodash__WEBPACK_IMPORTED_MODULE_1___default.a.merge({}, currentSettings, update);

    setCurrentSettings(mergedSettings);
    storeSettings(mergedSettings);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    const restoredSettings = restoreSettings();

    if (restoredSettings) {
      setCurrentSettings(restoredSettings);
    }
  }, []); // useEffect(() => {
  //   document.dir = currentSettings.direction;
  // }, [currentSettings]);

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(SettingsContext.Provider, {
    value: {
      settings: currentSettings,
      saveSettings: handleSaveSettings
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 5
    }
  }, children);
};
const SettingsConsumer = SettingsContext.Consumer;
/* harmony default export */ __webpack_exports__["default"] = (SettingsContext);

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./App */ "./src/App.js");
/* harmony import */ var _serviceWorker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./serviceWorker */ "./src/serviceWorker.js");
/* harmony import */ var _src_scss_main_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/scss/main.css */ "./src/scss/main.css");
/* harmony import */ var _src_scss_main_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_src_scss_main_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ethersproject/providers */ "./node_modules/@ethersproject/providers/lib.esm/index.js");
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @web3-react/core */ "./node_modules/@web3-react/core/dist/core.esm.js");
/* harmony import */ var src_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/constants */ "./src/constants/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/index.js";








const Web3ProviderNetwork = Object(_web3_react_core__WEBPACK_IMPORTED_MODULE_6__["createWeb3ReactRoot"])(src_constants__WEBPACK_IMPORTED_MODULE_7__["NetworkContextName"]);

function getLibrary(provider) {
  const library = new _ethersproject_providers__WEBPACK_IMPORTED_MODULE_5__["Web3Provider"](provider);
  library.pollingInterval = 15000;
  return library;
}

react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_web3_react_core__WEBPACK_IMPORTED_MODULE_6__["Web3ReactProvider"], {
  getLibrary: getLibrary,
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 3
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Web3ProviderNetwork, {
  getLibrary: getLibrary,
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_App__WEBPACK_IMPORTED_MODULE_2__["default"], {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 7
  }
}))), document.getElementById("root")); // If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA

_serviceWorker__WEBPACK_IMPORTED_MODULE_3__["unregister"]();

/***/ }),

/***/ "./src/layouts/DashboardLayout/NavBar/NavItem.js":
/*!*******************************************************!*\
  !*** ./src/layouts/DashboardLayout/NavBar/NavItem.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clsx */ "./node_modules/clsx/dist/clsx.m.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/icons/ExpandMore */ "./node_modules/@material-ui/icons/ExpandMore.js");
/* harmony import */ var _material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/ExpandLess */ "./node_modules/@material-ui/icons/ExpandLess.js");
/* harmony import */ var _material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/DashboardLayout/NavBar/NavItem.js";







const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["makeStyles"])(theme => ({
  item: {
    display: "block",
    paddingTop: 0,
    paddingBottom: 0
  },
  itemLeaf: {
    display: "flex",
    paddingTop: "6px",
    paddingBottom: 0
  },
  button: {
    color: "#707070",
    padding: "10px 0",
    justifyContent: "flex-start",
    textTransform: "none",
    letterSpacing: 0,
    width: "100%"
  },
  buttonLeaf: {
    color: "#fff",
    padding: "10px 8px",
    justifyContent: "flex-start",
    textTransform: "none",
    letterSpacing: 0,
    fontSize: "14px",
    width: "100%",
    borderLeft: "solid 8px transparent",
    borderRadius: "2px",
    "&:hover": {
      background: "#1EB808",
      color: "#fff"
    }
  },
  icon: {
    display: "flex",
    alignItems: "center",
    marginRight: theme.spacing(2),
    marginLeft: theme.spacing(1)
  },
  active: {
    // color: "#00e0b0",
    background: "#1EB808",
    color: "#fff",
    borderRight: "3px solid #1EB808",
    fontWeight: "600",
    "& $title": {
      fontWeight: theme.typography.fontWeightMedium
    },
    "& $icon": {
      color: "00e0b0"
    }
  }
}));

const NavItem = ({
  children,
  className,
  depth,
  href,
  icon: Icon,
  info: Info,
  open: openProp,
  title,
  ...rest
}) => {
  const classes = useStyles();
  const [open, setOpen] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(openProp);

  const handleToggle = () => {
    setOpen(prevOpen => !prevOpen);
  };

  let paddingLeft = 8;

  if (depth > 0) {
    paddingLeft = 32 + 8 * depth;
  }

  const style = {
    paddingLeft
  };

  if (children) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["ListItem"], Object.assign({
      className: Object(clsx__WEBPACK_IMPORTED_MODULE_2__["default"])(classes.item, className),
      disableGutters: true,
      key: title
    }, rest, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 7
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      className: classes.button,
      onClick: handleToggle,
      style: {
        color: "#ccc"
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 100,
        columnNumber: 9
      }
    }, Icon && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Icon, {
      className: classes.icon,
      size: "20",
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 20
      }
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      className: classes.title,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 106,
        columnNumber: 11
      }
    }, title), open ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_6___default.a, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 19
      }
    }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_5___default.a, {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 40
      }
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Collapse"], {
      in: open,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 109,
        columnNumber: 9
      }
    }, children));
  }

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["ListItem"], Object.assign({
    className: Object(clsx__WEBPACK_IMPORTED_MODULE_2__["default"])(classes.itemLeaf, className),
    disableGutters: true,
    key: title
  }, rest, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 115,
      columnNumber: 5
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Button"], {
    activeClassName: classes.active,
    className: Object(clsx__WEBPACK_IMPORTED_MODULE_2__["default"])(classes.buttonLeaf, `depth-${depth}`),
    component: react_router_dom__WEBPACK_IMPORTED_MODULE_1__["NavLink"],
    exact: true,
    style: style,
    to: href,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 121,
      columnNumber: 7
    }
  }, Icon && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Icon, {
    className: classes.icon,
    size: "20",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 129,
      columnNumber: 18
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: classes.title,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 130,
      columnNumber: 9
    }
  }, title), Info && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(Info, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 131,
      columnNumber: 18
    }
  })));
};

NavItem.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.node,
  className: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  depth: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number.isRequired,
  href: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  icon: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.elementType,
  info: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.elementType,
  open: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  title: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string.isRequired
};
NavItem.defaultProps = {
  open: false
};
/* harmony default export */ __webpack_exports__["default"] = (NavItem);

/***/ }),

/***/ "./src/layouts/DashboardLayout/NavBar/index.js":
/*!*****************************************************!*\
  !*** ./src/layouts/DashboardLayout/NavBar/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-perfect-scrollbar */ "./node_modules/react-perfect-scrollbar/lib/index.js");
/* harmony import */ var react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var src_component_Logo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/component/Logo */ "./src/component/Logo.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-icons/fa */ "./node_modules/react-icons/fa/index.esm.js");
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-icons/hi */ "./node_modules/react-icons/hi/index.esm.js");
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-icons/ri */ "./node_modules/react-icons/ri/index.esm.js");
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-icons/io5 */ "./node_modules/react-icons/io5/index.esm.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-icons/md */ "./node_modules/react-icons/md/index.esm.js");
/* harmony import */ var react_icons_gi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-icons/gi */ "./node_modules/react-icons/gi/index.esm.js");
/* harmony import */ var _NavItem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./NavItem */ "./src/layouts/DashboardLayout/NavBar/NavItem.js");
/* harmony import */ var _material_ui_icons_People__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @material-ui/icons/People */ "./node_modules/@material-ui/icons/People.js");
/* harmony import */ var _material_ui_icons_People__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_People__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @material-ui/icons/Dashboard */ "./node_modules/@material-ui/icons/Dashboard.js");
/* harmony import */ var _material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _material_ui_icons_Person__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @material-ui/icons/Person */ "./node_modules/@material-ui/icons/Person.js");
/* harmony import */ var _material_ui_icons_Person__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Person__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _material_ui_icons_InsertDriveFile__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @material-ui/icons/InsertDriveFile */ "./node_modules/@material-ui/icons/InsertDriveFile.js");
/* harmony import */ var _material_ui_icons_InsertDriveFile__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_InsertDriveFile__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _material_ui_icons_DevicesOther__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @material-ui/icons/DevicesOther */ "./node_modules/@material-ui/icons/DevicesOther.js");
/* harmony import */ var _material_ui_icons_DevicesOther__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_DevicesOther__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _material_ui_icons_RecentActors__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @material-ui/icons/RecentActors */ "./node_modules/@material-ui/icons/RecentActors.js");
/* harmony import */ var _material_ui_icons_RecentActors__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_RecentActors__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _material_ui_icons_Subscriptions__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @material-ui/icons/Subscriptions */ "./node_modules/@material-ui/icons/Subscriptions.js");
/* harmony import */ var _material_ui_icons_Subscriptions__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Subscriptions__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _material_ui_icons_SupervisorAccount__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @material-ui/icons/SupervisorAccount */ "./node_modules/@material-ui/icons/SupervisorAccount.js");
/* harmony import */ var _material_ui_icons_SupervisorAccount__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_SupervisorAccount__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _material_ui_icons_ExitToApp__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @material-ui/icons/ExitToApp */ "./node_modules/@material-ui/icons/ExitToApp.js");
/* harmony import */ var _material_ui_icons_ExitToApp__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExitToApp__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _material_ui_icons_Equalizer__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @material-ui/icons/Equalizer */ "./node_modules/@material-ui/icons/Equalizer.js");
/* harmony import */ var _material_ui_icons_Equalizer__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Equalizer__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @material-ui/core/Dialog */ "./node_modules/@material-ui/core/esm/Dialog/index.js");
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @material-ui/core/DialogActions */ "./node_modules/@material-ui/core/esm/DialogActions/index.js");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @material-ui/core/DialogContent */ "./node_modules/@material-ui/core/esm/DialogContent/index.js");
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @material-ui/core/DialogContentText */ "./node_modules/@material-ui/core/esm/DialogContentText/index.js");
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @material-ui/core/DialogTitle */ "./node_modules/@material-ui/core/esm/DialogTitle/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/DashboardLayout/NavBar/index.js";

/* eslint-disable no-use-before-define */





























const sections = [{
  items: [{
    title: "Dashboard",
    icon: _material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_15___default.a,
    href: "/dashboard"
  }, {
    title: "User Management",
    icon: _material_ui_icons_People__WEBPACK_IMPORTED_MODULE_14___default.a,
    href: "/users"
  }, {
    title: "Staking Management",
    icon: _material_ui_icons_Subscriptions__WEBPACK_IMPORTED_MODULE_20___default.a,
    href: "/categoryMgmt"
  }, {
    title: "Static Content Management",
    icon: react_icons_hi__WEBPACK_IMPORTED_MODULE_7__["HiDocumentText"],
    href: "/resouceMgmt"
  }, {
    title: "Partner's Management",
    icon: _material_ui_icons_SupervisorAccount__WEBPACK_IMPORTED_MODULE_21___default.a,
    href: "/contentMgmt"
  }, {
    title: "Press & Media Management",
    icon: react_icons_bi__WEBPACK_IMPORTED_MODULE_10__["BiNews"],
    href: "/pressMedia"
  } // {
  //   title: "Device List",
  //   icon: DevicesOtherIcon,
  //   href: "/devicelist",
  // },
  ]
}];
const sectionsBelow = [{
  items: [{
    // title: "Logout",
    icon: _material_ui_icons_ExitToApp__WEBPACK_IMPORTED_MODULE_22___default.a,
    href: "/terms-and-condition"
  } // {
  //   title: "Privacy Policy",
  //   //icon: PieChartIcon,
  //   href: "/privacy-policy",
  // },
  ]
}];

function renderNavItems({
  items,
  pathname,
  depth = 0
}) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["List"], {
    disablePadding: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 5
    }
  }, items.reduce((acc, item) => reduceChildRoutes({
    acc,
    item,
    pathname,
    depth
  }), []));
}

function reduceChildRoutes({
  acc,
  pathname,
  item,
  depth
}) {
  const key = item.title + depth;

  if (item.items) {
    const open = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["matchPath"])(pathname, {
      path: item.href,
      exact: false
    });
    acc.push( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NavItem__WEBPACK_IMPORTED_MODULE_13__["default"], {
      depth: depth,
      icon: item.icon,
      info: item.info,
      key: key,
      open: Boolean(open),
      title: item.title,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 7
      }
    }, renderNavItems({
      depth: depth + 1,
      pathname,
      items: item.items
    })));
  } else {
    acc.push( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NavItem__WEBPACK_IMPORTED_MODULE_13__["default"], {
      depth: depth,
      href: item.href,
      icon: item.icon,
      info: item.info,
      key: key,
      title: item.title,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 149,
        columnNumber: 7
      }
    }));
  }

  return acc;
}

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["makeStyles"])(theme => ({
  mobileDrawer: {
    width: 256,
    background: "radial-gradient(30.95% 30.95% at 30.74% 10.25%, rgb(3 3 2 / 20%) 0%, rgba(30, 184, 8, 0) 100%), radial-gradient(86.99% 51.58% at 86.99% 48.42%, rgba(30, 184, 8, 0.3) 0%, rgba(0, 0, 0, 0) 100%), #000000",
    boxShadow: "rgb(90 114 123 / 11%) 0px 7px 30px"
  },
  desktopDrawer: {
    width: 256,
    top: 0,
    height: "100%",
    background: "radial-gradient(30.95% 30.95% at 30.74% 10.25%, rgb(3 3 2 / 20%) 0%, rgba(30, 184, 8, 0) 100%), radial-gradient(86.99% 51.58% at 86.99% 48.42%, rgba(30, 184, 8, 0.3) 0%, rgba(0, 0, 0, 0) 100%), #000000",
    boxShadow: "rgb(90 114 123 / 11%) 0px 7px 30px 0px"
  },
  avatar: {
    cursor: "pointer",
    width: 64,
    height: 64
  },
  socialIcon: {
    cursor: "pointer",
    marginRight: 5
  },
  logoicon: {
    display: "flex",
    marginTop: "16px",
    alignItems: "center",
    marginLeft: "30px"
  },
  logoutbutton: {
    justifyContent: "space-between",
    paddingLeft: 10,
    borderRadius: 0,
    width: "60px",
    textAlign: "center"
  }
}));

const NavBar = ({
  onMobileClose,
  openMobile
}) => {
  const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_0___default.a.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const classes = useStyles();
  const location = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["useLocation"])();
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["useHistory"])();
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (openMobile && onMobileClose) {
      onMobileClose();
    } // eslint-disable-next-line react-hooks/exhaustive-deps

  }, [location.pathname]);
  const content = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Box"], {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 224,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Box"], {
    padding: 0,
    className: classes.logoicon,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 226,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(src_component_Logo__WEBPACK_IMPORTED_MODULE_5__["default"], {
    width: "180",
    style: {
      width: "80px",
      cursor: "pointer"
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 227,
      columnNumber: 9
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_perfect_scrollbar__WEBPACK_IMPORTED_MODULE_2___default.a, {
    options: {
      suppressScrollX: true
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 237,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Box"], {
    py: 2,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 238,
      columnNumber: 9
    }
  }, sections.map((section, i) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["List"], {
    key: `menu${i}`,
    subheader: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["ListSubheader"], {
      disableGutters: true,
      disableSticky: true,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 243,
        columnNumber: 17
      }
    }, section.subheader),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 240,
      columnNumber: 13
    }
  }, renderNavItems({
    items: section.items,
    pathname: location.pathname
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Box"], {
    className: "side_nev_Bottom",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 255,
      columnNumber: 9
    }
  }, sectionsBelow.map((section, i) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["List"], {
    key: `menu${i}`,
    subheader: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["ListSubheader"], {
      disableGutters: true,
      disableSticky: true,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 260,
        columnNumber: 17
      }
    }, section.subheader),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 257,
      columnNumber: 13
    }
  }, section.items.map((itemList, i) => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Box"], {
      align: "left",
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 267,
        columnNumber: 19
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      fullWidth: true,
      color: "primary",
      startIcon: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_io5__WEBPACK_IMPORTED_MODULE_9__["IoLogOutOutline"], {
        style: {
          fontSize: "40px",
          color: "#1EB808"
        },
        __self: undefined,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 272,
          columnNumber: 25
        }
      }),
      key: i,
      className: classes.logoutbutton,
      style: {},
      onClick: handleClickOpen,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 268,
        columnNumber: 21
      }
    }, itemList.title), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_24__["default"], {
      open: open,
      fullWidth: true,
      maxWidth: "sm",
      onClose: handleClose,
      "aria-labelledby": "alert-dialog-title",
      "aria-describedby": "alert-dialog-description",
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 287,
        columnNumber: 21
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Typography"], {
      variant: "h2",
      align: "center",
      style: {
        fontSize: "24px"
      },
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 295,
        columnNumber: 23
      }
    }, "Logout"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_26__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 302,
        columnNumber: 23
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_27__["default"], {
      id: "alert-dialog-description",
      align: "center",
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 303,
        columnNumber: 25
      }
    }, "Are you sure you want to logout?")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_25__["default"], {
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 310,
        columnNumber: 23
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      onClick: handleClose,
      variant: "contained",
      color: "primary",
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 311,
        columnNumber: 25
      }
    }, "Yes"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      variant: "contained",
      color: "secondary",
      onClick: handleClose,
      autoFocus: true,
      __self: undefined,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 318,
        columnNumber: 25
      }
    }, "No"))));
  }))))));
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Hidden"], {
    lgUp: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 340,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Drawer"], {
    anchor: "left",
    classes: {
      paper: classes.mobileDrawer
    },
    onClose: onMobileClose,
    open: openMobile,
    variant: "temporary",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 341,
      columnNumber: 9
    }
  }, content)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Hidden"], {
    mdDown: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 351,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Drawer"], {
    anchor: "left",
    classes: {
      paper: classes.desktopDrawer
    },
    open: true,
    variant: "persistent",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 352,
      columnNumber: 9
    }
  }, content)));
};

NavBar.propTypes = {
  onMobileClose: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  openMobile: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (NavBar);

/***/ }),

/***/ "./src/layouts/DashboardLayout/TopBar/index.js":
/*!*****************************************************!*\
  !*** ./src/layouts/DashboardLayout/TopBar/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! clsx */ "./node_modules/clsx/dist/clsx.m.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-feather */ "./node_modules/react-feather/dist/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/DashboardLayout/TopBar/index.js";




 // import { TopBarData } from 'src/layouts/HomeLayout/TopBar';

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
  root: {
    background: "#000" // backgroundColor: theme.palette.secondary.main,

  },
  toolbar: {
    height: 70,
    padding: "0 10px"
  },
  logo: {
    marginRight: theme.spacing(2)
  },
  link: {
    fontWeight: theme.typography.fontWeightMedium,
    "& + &": {
      marginLeft: theme.spacing(2)
    }
  },
  divider: {
    width: 1,
    height: 32,
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2)
  }
}));

const TopBar = ({
  className,
  onMobileNavOpen,
  ...rest
}) => {
  const classes = useStyles();
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["AppBar"], Object.assign({
    elevation: 0,
    className: Object(clsx__WEBPACK_IMPORTED_MODULE_1__["default"])(classes.root, className),
    color: "inherit"
  }, rest, {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 5
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Toolbar"], {
    className: classes.toolbar,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Hidden"], {
    lgUp: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["IconButton"], {
    color: "#00e0b0",
    onClick: onMobileNavOpen,
    style: {
      marginRight: 10
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["SvgIcon"], {
    fontSize: "small",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_feather__WEBPACK_IMPORTED_MODULE_4__["Menu"], {
    style: {
      color: "#1EB808"
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 15
    }
  }))))));
};

TopBar.propTypes = {
  className: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
};
TopBar.defaultProps = {
  onMobileNavOpen: () => {}
};
/* harmony default export */ __webpack_exports__["default"] = (TopBar);

/***/ }),

/***/ "./src/layouts/DashboardLayout/index.js":
/*!**********************************************!*\
  !*** ./src/layouts/DashboardLayout/index.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _NavBar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavBar */ "./src/layouts/DashboardLayout/NavBar/index.js");
/* harmony import */ var _TopBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TopBar */ "./src/layouts/DashboardLayout/TopBar/index.js");
/* harmony import */ var _HomeLayout_SocialBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../HomeLayout/SocialBar */ "./src/layouts/HomeLayout/SocialBar.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/DashboardLayout/index.js";






const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["makeStyles"])(theme => ({
  root: {
    backgroundColor: theme.palette.background.dark,
    display: "flex",
    height: "100%",
    overflow: "hidden",
    width: "100%"
  },
  wrapper: {
    display: "flex",
    flex: "1 1 auto",
    overflow: "hidden",
    background: "radial-gradient(30.95% 30.95% at 30.74% 10.25%, rgb(3 3 2 / 20%) 0%, rgba(30, 184, 8, 0) 100%), radial-gradient(86.99% 51.58% at 86.99% 48.42%, rgb(30 184 8 / 21%) 0%, rgba(0, 0, 0, 0) 100%), #000000",
    paddingTop: 70,
    [theme.breakpoints.up("lg")]: {
      paddingLeft: 256
    }
  },
  contentContainer: {
    display: "flex",
    flex: "1 1 auto",
    overflow: "hidden",
    background: theme.palette.background.dark1
  },
  content: {
    flex: "1 1 auto",
    // height: "100%",
    overflow: "hidden",
    position: "relative",
    WebkitOverflowScrolling: "touch",
    padding: "10px 50px 0px ",
    minHeight: "91vh",
    [theme.breakpoints.down("sm")]: {
      padding: "10px 20px 0px "
    }
  }
}));

const DashboardLayout = ({
  children
}) => {
  const classes = useStyles();
  const [isMobileNavOpen, setMobileNavOpen] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.root,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TopBar__WEBPACK_IMPORTED_MODULE_4__["default"], {
    onMobileNavOpen: () => setMobileNavOpen(true),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_NavBar__WEBPACK_IMPORTED_MODULE_3__["default"], {
    onMobileClose: () => setMobileNavOpen(false),
    openMobile: isMobileNavOpen,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 7
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.wrapper,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.contentContainer,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.content,
    id: "main-scroll",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 11
    }
  }, children))));
};

DashboardLayout.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.node
};
/* harmony default export */ __webpack_exports__["default"] = (DashboardLayout);

/***/ }),

/***/ "./src/layouts/HomeLayout/Footer.js":
/*!******************************************!*\
  !*** ./src/layouts/HomeLayout/Footer.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Liquidity; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/fa */ "./node_modules/react-icons/fa/index.esm.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/HomeLayout/Footer.js";








const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["makeStyles"])(theme => ({
  footerSection: {
    background: theme.palette.background.footercolor,
    // backgroundImage: "url('./images/fly.png')",
    position: "relative",
    padding: "50px 0px",
    backgroundPosition: " bottom left",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
    [theme.breakpoints.up("sm")]: {
      paddingTop: theme.spacing(4)
    },
    [theme.breakpoints.up("md")]: {
      paddingTop: theme.spacing(4)
    },
    // "&"
    "& h5": {
      fontWeight: "bold",
      fontSize: "16px",
      letterSpacing: "2px",
      textTransform: "uppercase",
      color: theme.palette.text.secondary
    },
    "& ul": {
      paddingLeft: "0"
    },
    "& p": {
      marginBottom: "0px",
      marginTop: "10px",
      fontWeight: "500",
      fontSize: "12px",
      lineHeight: "18px",
      color: theme.palette.text.secondary
    }
  },
  footerBg: {
    position: "absolute",
    bottom: "0",
    width: "100%",
    left: "0"
  },
  ListItem: {
    paddingLeft: "0px"
  },
  borderBottmo: {
    overflow: "hidden",
    background: theme.palette.background.footercolor,
    paddingTop: theme.spacing(6),
    paddingBottom: theme.spacing(6),
    [theme.breakpoints.down("md")]: {
      paddingTop: theme.spacing(3),
      paddingBottom: theme.spacing(3)
    }
  },
  signupBtn: {
    color: "#fff",
    display: "flex",
    fontSize: "16px",
    fontWeight: "bold",
    height: "45px",
    minWidth: "100px",
    borderRadius: "50px",
    position: "absolute",
    top: "5px",
    right: "5px",
    boxShadow: "0px 8px 24px rgba(38, 50, 56, 0.1), 0px 16px 32px rgba(38, 50, 56, 0.08)",
    lineHeight: "36px",
    alignItems: "center",
    textAlign: "center",
    letterSpacing: " 1px",
    background: "#040405",
    "&:hover": {
      background: "#040405",
      color: theme.palette.text.secondary
    }
  },
  icons: {
    justify: "flex-end",
    [theme.breakpoints.down("sm")]: {
      justify: "center"
    }
  },
  textSection: {
    "& h3": {
      color: "#fff",
      //fontFamily: "'Red Rose', cursive",
      fontSize: "24px",
      fontWeight: "500",
      marginBottom: "30px",
      [theme.breakpoints.down("xs")]: {
        fontSize: "18px",
        marginBottom: "10px"
      }
    },
    "& p": {
      color: "#fff",
      //fontFamily: "'Russo One', sans-serif",
      fontSize: "15px",
      [theme.breakpoints.down("xs")]: {
        fontSize: "13px"
      }
    }
  },
  footerbase: {
    background: theme.palette.background.subfootercolor,
    // backgroundImage: "url('./images/fly.png')",
    position: "relative",
    padding: "15px 0px"
  },
  leftcontent: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    [theme.breakpoints.down("xs")]: {// flexDirection: "column",
    },
    "& p": {
      color: "#fff",
      fontSize: "12px",
      marginRight: "15px",
      [theme.breakpoints.down("xs")]: {
        marginBottom: "15px"
      }
    }
  },
  socilaIcons: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    "& svg": {
      color: "#fff",
      fontSize: "15px",
      margin: "0 8px",
      [theme.breakpoints.down("xs")]: {
        fontSize: " 15px",
        marginLeft: "10px"
      },
      "&:hover": {
        color: theme.palette.text.secondary,
        textDecoration: "none"
      }
    }
  },
  rightcontent: {
    display: "flex",
    // alignItems: "center",
    justifyContent: "end",
    [theme.breakpoints.down("xs")]: {
      justifyContent: "end"
    },
    "& p": {
      color: theme.palette.text.secondary,
      fontSize: "12px"
    }
  }
}));
function Liquidity() {
  const classes = useStyles();
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.footerSection,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 182,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 183,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 184,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    container: true,
    justify: "space-around",
    spacing: 1,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 185,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    lg: 3,
    md: 3,
    xs: 6,
    sm: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 186,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.textSection,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 187,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "h3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 188,
      columnNumber: 19
    }
  }, "PRODUCTS "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 189,
      columnNumber: 19
    }
  }, "Spot"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 190,
      columnNumber: 19
    }
  }, "Inverse Perpetual"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 191,
      columnNumber: 19
    }
  }, "USDT Perpetual"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 192,
      columnNumber: 19
    }
  }, "Inverse Futures"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 193,
      columnNumber: 19
    }
  }, "Services"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    lg: 3,
    md: 3,
    xs: 6,
    sm: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 196,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.textSection,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 197,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "h3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 198,
      columnNumber: 19
    }
  }, "SERVICES"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 199,
      columnNumber: 19
    }
  }, "Buy Crypto"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 200,
      columnNumber: 19
    }
  }, "Markets"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 201,
      columnNumber: 19
    }
  }, "Trading Fee"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 202,
      columnNumber: 19
    }
  }, "Affiliate Program"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 19
    }
  }, "Referral Program"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 204,
      columnNumber: 19
    }
  }, "API"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 205,
      columnNumber: 19
    }
  }, "Listing Application"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    lg: 3,
    md: 3,
    xs: 6,
    sm: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 208,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.textSection,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 209,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "h3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 210,
      columnNumber: 19
    }
  }, "SUPPORT"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 211,
      columnNumber: 19
    }
  }, "BitcoMine Learn"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 212,
      columnNumber: 19
    }
  }, "Help Center"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 213,
      columnNumber: 19
    }
  }, "User Feedback"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    lg: 3,
    md: 3,
    xs: 6,
    sm: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 216,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.textSection,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 217,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "h3",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 218,
      columnNumber: 19
    }
  }, "ABOUT"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 219,
      columnNumber: 19
    }
  }, "About BitcoMine"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 220,
      columnNumber: 19
    }
  }, "Authenticity Check"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 221,
      columnNumber: 19
    }
  }, "Blog"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 222,
      columnNumber: 19
    }
  }, "Announcements"))))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.footerbase,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 229,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 230,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    container: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 231,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    xs: 12,
    sm: 8,
    md: 6,
    lg: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 232,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.leftcontent,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 233,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Hidden"], {
    xsDown: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 234,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 235,
      columnNumber: 19
    }
  }, "\xA9 2022 Bitcomine")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
    to: "/terms-condition",
    style: {
      textDecoration: "none"
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 237,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 241,
      columnNumber: 19
    }
  }, "Terms & Conditions")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
    to: "privacy-policy",
    style: {
      textDecoration: "none"
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 243,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 247,
      columnNumber: 19
    }
  }, "privacy Policy")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Link"], {
    to: "cookies",
    style: {
      textDecoration: "none"
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 249,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 250,
      columnNumber: 19
    }
  }, "Cookie Settings")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Hidden"], {
    xsDown: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 255,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    xs: 6,
    sm: 4,
    md: 6,
    lg: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 256,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.rightcontent,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 257,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.socilaIcons,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 259,
      columnNumber: 19
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://www.instagram.com/metaknightsnft/",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 260,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaInstagram"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 265,
      columnNumber: 23
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://twitter.com/MetaKnightsNFT",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 267,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaTwitter"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 272,
      columnNumber: 23
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://discord.gg/YZpk74EJwS",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 274,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaFacebookF"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 276,
      columnNumber: 23
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://opensea.io/collection/metaknightsnft",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 278,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaYoutube"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 283,
      columnNumber: 23
    }
  })))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Hidden"], {
    smUp: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 290,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    xs: 6,
    sm: 4,
    md: 6,
    lg: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 291,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.leftcontent,
    justifyContent: "start",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 292,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
    variant: "body1",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 293,
      columnNumber: 19
    }
  }, " ", "\xA9 2022 Bitcomine"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    xs: 6,
    sm: 4,
    md: 6,
    lg: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 299,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.rightcontent,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 300,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.socilaIcons,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 302,
      columnNumber: 19
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://www.instagram.com/metaknightsnft/",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 303,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaInstagram"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 308,
      columnNumber: 23
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://twitter.com/MetaKnightsNFT",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 310,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaTwitter"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 315,
      columnNumber: 23
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://discord.gg/YZpk74EJwS",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 317,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaFacebookF"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 319,
      columnNumber: 23
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
    target: "_blank",
    href: "https://opensea.io/collection/metaknightsnft",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 321,
      columnNumber: 21
    }
  }, " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__["FaYoutube"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 326,
      columnNumber: 23
    }
  }))))))))));
}

/***/ }),

/***/ "./src/layouts/HomeLayout/SocialBar.js":
/*!*********************************************!*\
  !*** ./src/layouts/HomeLayout/SocialBar.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Liquidity; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/icons/Twitter */ "./node_modules/@material-ui/icons/Twitter.js");
/* harmony import */ var _material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/Facebook */ "./node_modules/@material-ui/icons/Facebook.js");
/* harmony import */ var _material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons/Instagram */ "./node_modules/@material-ui/icons/Instagram.js");
/* harmony import */ var _material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/icons/YouTube */ "./node_modules/@material-ui/icons/YouTube.js");
/* harmony import */ var _material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/IconButton */ "./node_modules/@material-ui/core/esm/IconButton/index.js");
/* harmony import */ var _material_ui_icons_Brightness3__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/icons/Brightness3 */ "./node_modules/@material-ui/icons/Brightness3.js");
/* harmony import */ var _material_ui_icons_Brightness3__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Brightness3__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _material_ui_icons_Brightness7__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/icons/Brightness7 */ "./node_modules/@material-ui/icons/Brightness7.js");
/* harmony import */ var _material_ui_icons_Brightness7__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Brightness7__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_theme_typography__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/theme/typography */ "./src/theme/typography.js");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var src_context_Auth__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/context/Auth */ "./src/context/Auth.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/HomeLayout/SocialBar.js";














const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["makeStyles"])(theme => ({
  socialBox: {
    background: theme.palette.background.subfootercolor,
    '& ul': {
      padding: 0,
      display: 'flex',
      alignItems: 'center',
      '& li': {
        width: 'auto',
        padding: '5px',
        '& a': {
          color: '#fff',
          textDecoration: 'none',
          fontSize: '14px',
          fontWeight: 300,
          '&:hover': {
            color: '#5a86ff'
          },
          '& svg': {
            fontSize: '20px',
            [theme.breakpoints.down('xs')]: {
              fontSize: '17px'
            }
          }
        }
      }
    },
    '& .leftBox': {
      justifyContent: 'flex-end'
    },
    '& .submit': {
      backgroundColor: '#5a86ff',
      paddingLeft: '5px',
      paddingRight: '5px',
      [theme.breakpoints.down('xs')]: {
        fontSize: '12px'
      },
      '&:hover': {
        color: '#fff'
      }
    }
  },
  toggleButtonShell: {
    // border: '1px solid #000',
    borderRadius: '32px',
    width: '50px',
    // backgroundColor: '#000',
    height: '18px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '4px 3px'
  },
  toggleButton: {
    border: '1px solid #000',
    borderRadius: '100%',
    display: 'flex',
    padding: '6px',
    cursor: 'pointer'
  }
}));
function Liquidity() {
  const classes = useStyles();
  const auth = Object(react__WEBPACK_IMPORTED_MODULE_0__["useContext"])(src_context_Auth__WEBPACK_IMPORTED_MODULE_13__["AuthContext"]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.socialBox,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 94,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    container: true,
    alignItems: "center",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    xs: 6,
    sm: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 96,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["List"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 97,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["ListItem"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 104,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_6__["Link"], {
    to: "",
    className: "submit",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 105,
      columnNumber: 17
    }
  }, "Submit your Token")))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    item: true,
    xs: 6,
    sm: 6,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 111,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["List"], {
    className: "leftBox",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 113,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["ListItem"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 114,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    href: "https://www.instagram.com/",
    target: "_blank",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 115,
      columnNumber: 19
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_4___default.a, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 116,
      columnNumber: 21
    }
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["ListItem"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 119,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    href: "https://twitter.com/",
    target: "_blank",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 120,
      columnNumber: 19
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_2___default.a, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 121,
      columnNumber: 21
    }
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["ListItem"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 124,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    href: "https://www.facebook.com/",
    target: "_blank",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 125,
      columnNumber: 19
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3___default.a, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 126,
      columnNumber: 21
    }
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["ListItem"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 129,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    href: "https://www.youtube.com/",
    target: "_blank",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 130,
      columnNumber: 19
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5___default.a, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 131,
      columnNumber: 21
    }
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: `${classes.toggleButtonShell} `,
    style: !auth.theme ? {
      backgroundColor: '#fff'
    } : {
      backgroundColor: '#4c4949',
      border: '1px solid #000'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_8__["default"] // className={classes.toggleButton}
  , {
    style: auth.theme ? {
      color: '#000',
      padding: '1px'
    } : {
      background: '#242538',
      padding: '1px'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_Brightness7__WEBPACK_IMPORTED_MODULE_10___default.a, {
    style: auth.theme ? {
      color: '#000',
      fontSize: '20px'
    } : {
      color: 'rgb(244 144 24)',
      fontSize: '20px'
    },
    onClick: () => auth === null || auth === void 0 ? void 0 : auth.setTheme(false),
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 151,
      columnNumber: 19
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_8__["default"] // className={classes.toggleButton}
  , {
    style: !auth.theme ? {
      color: '#000',
      padding: '1px'
    } : {
      background: '#000',
      padding: '1px'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 160,
      columnNumber: 17
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_icons_Brightness3__WEBPACK_IMPORTED_MODULE_9___default.a, {
    onClick: () => auth === null || auth === void 0 ? void 0 : auth.setTheme(true),
    style: !auth.theme ? {
      color: '#000',
      transitionDuration: '4s',
      fontSize: '20px'
    } : {
      color: '#ffc107',
      transform: 'rotate(152deg)',
      transitionDuration: '4s',
      fontSize: '20px'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 168,
      columnNumber: 19
    }
  }))))))));
}

/***/ }),

/***/ "./src/layouts/HomeLayout/TopBar.js":
/*!******************************************!*\
  !*** ./src/layouts/HomeLayout/TopBar.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Header; });
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/icons/Menu */ "./node_modules/@material-ui/icons/Menu.js");
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/fa */ "./node_modules/react-icons/fa/index.esm.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var _component_Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../component/Logo */ "./src/component/Logo.js");
/* harmony import */ var _material_ui_core_ClickAwayListener__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/ClickAwayListener */ "./node_modules/@material-ui/core/esm/ClickAwayListener/index.js");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/Dialog */ "./node_modules/@material-ui/core/esm/Dialog/index.js");
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/DialogActions */ "./node_modules/@material-ui/core/esm/DialogActions/index.js");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/core/DialogContent */ "./node_modules/@material-ui/core/esm/DialogContent/index.js");
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/DialogContentText */ "./node_modules/@material-ui/core/esm/DialogContentText/index.js");
/* harmony import */ var _material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @material-ui/core/DialogTitle */ "./node_modules/@material-ui/core/esm/DialogTitle/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/HomeLayout/TopBar.js";














const StyledMenu = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8__["withStyles"])(theme => ({
  paper: {
    width: '188px !important',
    background: theme.palette.background.dark1,
    border: '1px solid #e1e1e1',
    borderTop: '3px solid #5a86ff',
    borderRadius: 0
  }
}))(props => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Menu"], Object.assign({
  elevation: 0,
  getContentAnchorEl: null,
  anchorOrigin: {
    vertical: 'bottom',
    horizontal: 'center'
  },
  transformOrigin: {
    vertical: 'top',
    horizontal: 'center'
  }
}, props, {
  __self: undefined,
  __source: {
    fileName: _jsxFileName,
    lineNumber: 42,
    columnNumber: 3
  }
})));
const StyledMenuItem = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_8__["withStyles"])(theme => ({
  root: {// "&:focus": {
    //   backgroundColor: theme.palette.primary.main,
    //   "& .MuiListItemIcon-root, & .MuiListItemText-primary": {
    //     color: theme.palette.common.white,
    //   },
    // },
  }
}))(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["MenuItem"]);
const headersData = [{
  label: 'HOME',
  href: '/'
}, {
  label: 'COINS',
  href: '/flow-chart'
}, {
  label: 'ADD TOKEN',
  href: '/add-token'
}, // {
//   label: "TOKEN ADD",
//   href: "/flow-chart",
// },
{
  label: 'WIKI',
  href: '/tokens'
}, {
  label: 'BLOG',
  href: '/login'
}, {
  label: 'CONTACT',
  href: '/contact-us'
}, {
  label: 'WHITE PAPER',
  href: '/'
} // {
//   label: "DASHBOARD",
//   href: "/dashboard",
// },
// {
//   label: "SignIn",
//   href: "/login",
// },
];
const headersData2 = [{
  label: 'HOME',
  href: '/'
}, {
  label: 'WHITE PAPER',
  href: '/'
}];
const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  menuButton: {
    color: theme.palette.text.black,
    borderBottom: '5px solid transparent',
    padding: ' 0px 10px',
    fontSize: ' 16px',
    fontWeight: ' 800 !important',
    minWidth: '100px',
    lineHeight: '24px',
    borderRadius: 0,
    letterSpacing: '1px',
    height: '100%',
    '@media (max-width: 900px)': {
      fontStyle: 'normal',
      letterSpacing: '-0.6px',
      lineHeight: '24px',
      color: '#FFF',
      padding: '15px !important',
      height: '51px',
      width: '100%',
      display: 'flex',
      justifyContent: 'flex-start',
      alignItems: 'flex-start'
    },
    '&:active': {
      borderBottom: '5px solid #5a86ff'
    },
    '&:hover': {
      borderBottom: '5px solid #5a86ff'
    }
  },
  toolbar: {
    padding: '0',
    background: theme.palette.background.dark1,
    marginTop: '40px',
    border: '1px solid #e1e1e1',
    borderRadius: '7px',
    overflow: 'hidden',
    boxShadow: 'rgb(99 99 99 / 20%) 0px 2px 8px 0px',
    display: 'flex',
    justifyContent: 'space-between',
    height: '90px',
    '@media (max-width: 900px)': {
      paddingLeft: '75px',
      paddingRight: '20px',
      height: '100%'
    }
  },
  maindrawer: {
    height: '100%',
    background: '#0c0731',
    width: '260px'
  },
  logoDrawer: {
    paddingLeft: '10px',
    width: '80px',
    marginBottom: '30px'
  },
  drawerContainer: {
    padding: '20px 0px ',
    height: '100%',
    background: '#242538',
    paddingLeft: ' 20px !important',
    width: '260px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start'
  },
  drawericon: {
    color: '#000',
    position: 'absolute',
    top: '0px',
    right: '-0px',
    fontSize: '25px'
  },
  logoImg: {
    width: '75px',
    // height: '44.5px',
    margin: ' 14px 15px 11px 0px',
    objectFit: 'contain',
    '@media (max-width: 500px)': {
      margin: ' 11px 1px 3px 0px',
      width: '52px'
    }
  },
  menuMobile: {
    fontSize: '16px',
    fontWeight: '400',
    fontStyle: 'normal',
    letterSpacing: '-0.6px',
    lineHeight: '1.75',
    color: '#fff',
    // borderBottom: "1px solid #3e3e3e",
    padding: '16px',
    '@media (max-width: 500px)': {
      padding: '7px 0',
      width: '100%'
    }
  },
  menuMobile2: {
    fontSize: '14px',
    fontWeight: '400',
    fontStyle: 'normal',
    letterSpacing: '-0.6px',
    lineHeight: '1.75',
    color: '#000',
    padding: '10px 5px !important',
    '@media (max-width: 500px)': {
      padding: '7px 0',
      width: '100%'
    }
  },
  paper1: {
    background: 'black',
    color: 'white'
  },
  containerHeight: {
    height: '100%',
    background: theme.palette.background.dark1
  },
  mainHeader: {
    border: '1px solid #e1e1e1',
    height: '60px',
    display: 'flex',
    padding: 0,
    overflow: 'hidden',
    boxShadow: 'rgb(99 99 99 / 20%) 0px 2px 8px 0px',
    marginTop: '16px',
    borderRadius: '7px',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    alignItems: 'center'
  },
  search: {
    height: '31px',
    position: 'relative',
    color: '#ABABAB',
    borderRadius: '100px',
    backgroundColor: '#E6E6E6',
    border: '1px solid #fff',
    '&:hover': {
      backgroundColor: '#ececec',
      border: '1px solid #300760'
    },
    marginLeft: 20,
    width: '140px',
    maxWidth: '257px',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(1),
      width: '180px'
    }
  },
  searchIcon: {
    fontSize: '16px',
    padding: theme.spacing(0, 2),
    color: '#000000',
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  inputRoot: {
    color: 'inherit',
    fontSize: '16px'
  },
  wallet: {
    fontSize: '14px',
    fontWeight: '400',
    fontStyle: 'normal',
    lineHeight: '21px',
    color: '#fff',
    border: '1px solid #ec0066',
    padding: '0 15px',
    background: '#ec0066',
    borderRadius: '50px',
    height: '31px',
    '&:hover': {
      background: '#fff',
      color: '#ec0066'
    },
    '@media (max-width: 900px)': {
      marginLeft: '12px',
      marginTop: '12px'
    }
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    fontSize: '13px',
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create('width'),
    width: '100px',
    [theme.breakpoints.up('sm')]: {
      width: '100%',
      '&:focus': {
        width: '100%'
      }
    }
  },
  submenu: {
    borderTop: '3px solid #300760',
    top: '25px !important'
  },
  logoBox: {
    height: '100%',
    borderRight: ' 1px solid #e1e1e1',
    '& a': {
      height: '100%',
      '& div': {
        height: '100%'
      }
    }
  },
  signinBox: {
    height: '100%',
    borderLeft: ' 1px solid #e1e1e1',
    [theme.breakpoints.down('md')]: {
      borderLeft: ' none'
    },
    '& button': {
      width: '100%',
      height: '100%',
      color: '#707070',
      fontSize: '12px !important',
      [theme.breakpoints.down('md')]: {
        width: 'auto',
        height: 'auto',
        color: '#fff',
        height: ' 60px'
      },
      '& label': {
        fontSize: '14px !important'
      }
    }
  },
  desktopbtn: {
    color: theme.palette.text.black
  },
  navcolor: {
    color: theme.palette.text.black
  }
}));
function Header() {
  const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_2___default.a.useState(null);

  const handleClose1 = () => {
    setAnchorEl(null);
  };

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const {
    menuMobile,
    menuButton,
    menuButton1,
    logoBox,
    signinBox,
    toolbar,
    drawerContainer,
    drawericon,
    logoDrawer,
    containerHeight,
    mainHeader,
    wallet,
    menuMobile2,
    submenu,
    desktopbtn,
    navcolor
  } = useStyles();
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["useHistory"])();
  console.log(history.location);
  const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    mobileView: false,
    drawerOpen: false
  });
  const [applicationCheck, setApplicationCheck] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])('');
  const {
    mobileView,
    drawerOpen
  } = state;
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    const setResponsiveness = () => {
      return window.innerWidth < 1220 ? setState(prevState => ({ ...prevState,
        mobileView: true
      })) : setState(prevState => ({ ...prevState,
        mobileView: false
      }));
    };

    setResponsiveness();
    window.addEventListener('resize', () => setResponsiveness());
  }, []);
  const [open1, setOpen1] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])({
    community: false,
    user: false
  });
  const anchorRef = {
    community: Object(react__WEBPACK_IMPORTED_MODULE_2__["useRef"])(null),
    user: Object(react__WEBPACK_IMPORTED_MODULE_2__["useRef"])(null)
  };
  Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
    setApplicationCheck(sessionStorage.getItem('token'));
  }, [sessionStorage.getItem('token')]); // const handleToggle = (name) => {
  //   setOpen1({ ...open1, [name]: !open1[name] });
  // };

  const handleClose2 = (event, name) => {
    if (anchorRef[name].current && anchorRef[name].current.contains(event.target)) {
      return;
    }

    setOpen1({ ...open1,
      [name]: false
    });
  };

  function handleListKeyDown(event, name) {
    if (event.key === 'Tab') {
      event.preventDefault();
      setOpen1({ ...open1,
        [name]: false
      });
    }
  }

  const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_2___default.a.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  }; // return focus to the button when we transitioned from !open -> open
  // const prevOpen = React.useRef(open1);
  // React.useEffect(() => {
  //   if (prevOpen.current === true && open1 === false) {
  //     anchorRef.current.focus();
  //   }
  //   prevOpen.current = open1;
  // }, [open1]);


  const displayDesktop = () => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Container"], {
      maxWidth: "lg",
      className: "p-0",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 466,
        columnNumber: 7
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Toolbar"], {
      className: toolbar,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 467,
        columnNumber: 9
      }
    }, femmecubatorLogo, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Grid"], {
      container: true,
      item: true,
      direction: "row",
      alignItems: "center",
      style: {
        paddingLeft: '0px',
        height: '100%'
      },
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 469,
        columnNumber: 11
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Grid"], {
      item: true,
      xs: 10,
      style: {
        height: '100%'
      },
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 476,
        columnNumber: 13
      }
    }, getMenuButtons()), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Grid"], {
      item: true,
      xs: 2,
      style: {
        height: '100%'
      },
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 479,
        columnNumber: 13
      }
    }, signin))));
  };

  const displayMobile = () => {
    const handleDrawerOpen = () => setState(prevState => ({ ...prevState,
      drawerOpen: true
    }));

    const handleDrawerClose = () => setState(prevState => ({ ...prevState,
      drawerOpen: false
    }));

    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Toolbar"], {
      className: mainHeader,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 495,
        columnNumber: 7
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Drawer"], {
      anchor: 'right',
      open: drawerOpen,
      onClose: handleDrawerClose,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 496,
        columnNumber: 9
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
      className: drawerContainer,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 503,
        columnNumber: 11
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("img", {
      className: logoDrawer,
      src: "images/logo.png",
      alt: "",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 504,
        columnNumber: 13
      }
    }), getDrawerChoices(), signin)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement("div", {
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 510,
        columnNumber: 9
      }
    }, femmecubatorLogo), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Grid"], {
      container: true,
      alignItems: "center",
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 512,
        columnNumber: 9
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Grid"], {
      item: true,
      xs: 9,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 513,
        columnNumber: 11
      }
    }, getDrawerChoices2()), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Grid"], {
      item: true,
      xs: 3,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 516,
        columnNumber: 11
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["IconButton"], {
      className: drawericon,
      edge: 'start',
      color: 'inherit',
      'aria-label': 'menu',
      'aria-haspopup': 'true',
      onClick: handleDrawerOpen,
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 517,
        columnNumber: 13
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_1___default.a, {
      width: "60px",
      height: "60px",
      style: {
        color: '#197ab3',
        fontSize: '30px'
      },
      __self: this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 527,
        columnNumber: 15
      }
    })))));
  };

  const getDrawerChoices = () => {
    return headersData.map(({
      label,
      href
    }) => {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Button"], {
        key: label,
        color: 'inherit',
        to: href,
        component: react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"],
        className: menuButton1,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 543,
          columnNumber: 11
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["MenuItem"], {
        className: menuMobile,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 552,
          columnNumber: 13
        }
      }, label)));
    });
  };

  const getDrawerChoices2 = () => {
    return headersData2.map(({
      label,
      href
    }) => {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Button"], {
        key: label,
        color: 'inherit',
        to: href,
        component: react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"],
        className: menuButton1,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 562,
          columnNumber: 11
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["MenuItem"], {
        className: menuMobile2,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 571,
          columnNumber: 13
        }
      }, label)));
    });
  };

  const femmecubatorLogo = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Box"], {
    className: logoBox,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 579,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    to: "/",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 580,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_component_Logo__WEBPACK_IMPORTED_MODULE_6__["default"], {
    className: "logoImg",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 581,
      columnNumber: 9
    }
  })));
  const signin = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Box"], {
    className: signinBox,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 587,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Button"], {
    "aria-controls": "simple-menu",
    "aria-haspopup": "true",
    onClick: handleClick,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 588,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__["FaUserCircle"], {
    style: {
      fontSize: '25px',
      marginRight: '10px'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 593,
      columnNumber: 9
    }
  }), ' ', !applicationCheck ? 'Sign In' : '', /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__["BiChevronDown"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 595,
      columnNumber: 9
    }
  })));

  const getMenuButtons = () => {
    return headersData.map(({
      label,
      href
    }) => {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Button"], {
        key: label,
        color: 'inherit',
        to: href,
        component: react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"],
        className: menuButton,
        __self: this,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 604,
          columnNumber: 11
        }
      }, label));
    });
  };

  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["AppBar"], {
    position: history.location.pathname !== '/' ? 'relative' : 'relative',
    elevation: 0 // style={{ backgroundColor: "#ccc0", border: "none" }}
    ,
    style: history.location.pathname !== '/' ? {
      backgroundColor: '#f5f7fa'
    } : {
      backgroundColor: '#f5f7fa'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 622,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Container"], {
    maxWidth: history.location.pathname !== '/' ? 'fixed' : 'fixed',
    className: containerHeight,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 632,
      columnNumber: 9
    }
  }, mobileView ? displayMobile() : displayDesktop())), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(StyledMenu, {
    id: "customized-menu",
    anchorEl: anchorEl,
    keepMounted: true,
    open: Boolean(anchorEl),
    onClose: handleClose1,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 640,
      columnNumber: 7
    }
  }, applicationCheck && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_2___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(StyledMenuItem, {
    className: "menutext",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 649,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    to: "/dashboard",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 650,
      columnNumber: 15
    }
  }, "Dashboard")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(StyledMenuItem, {
    className: "menutext",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 652,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    onClick: handleClickOpen,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 653,
      columnNumber: 15
    }
  }, "Logout"))), !applicationCheck && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(StyledMenuItem, {
    className: "menutext",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 658,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["Link"], {
    to: "/login",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 659,
      columnNumber: 13
    }
  }, "Login"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_9__["default"], {
    open: open,
    fullWidth: true,
    maxWidth: "sm",
    onClose: handleClose,
    "aria-labelledby": "alert-dialog-title",
    "aria-describedby": "alert-dialog-description",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 664,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core_DialogTitle__WEBPACK_IMPORTED_MODULE_13__["default"], {
    id: "alert-dialog-title",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 672,
      columnNumber: 9
    }
  }, 'Logout'), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_11__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 673,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_12__["default"], {
    id: "alert-dialog-description",
    align: "center",
    style: {
      color: '#000'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 674,
      columnNumber: 11
    }
  }, "Are you sure you want to logout?")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_10__["default"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 682,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Button"], {
    onClick: () => {
      history.push('/');
      window.sessionStorage.removeItem('token');
      window.sessionStorage.removeItem('userType');
      setOpen(false);
    },
    color: "primary",
    style: {
      color: '#5a86ff'
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 683,
      columnNumber: 11
    }
  }, "Yes"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["Button"], {
    onClick: handleClose,
    color: "primary",
    autoFocus: true,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 695,
      columnNumber: 11
    }
  }, "No"))));
}

/***/ }),

/***/ "./src/layouts/HomeLayout/index.js":
/*!*****************************************!*\
  !*** ./src/layouts/HomeLayout/index.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Footer */ "./src/layouts/HomeLayout/Footer.js");
/* harmony import */ var _TopBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TopBar */ "./src/layouts/HomeLayout/TopBar.js");
/* harmony import */ var _SocialBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SocialBar */ "./src/layouts/HomeLayout/SocialBar.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/HomeLayout/index.js";






const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["makeStyles"])(theme => ({
  root: {
    backgroundColor: '#fff'
  },
  MainLayout: {
    minHeight: 'calc(100vh - 415px)',
    // paddingTop: "50px",
    backgroundColor: '#f5f7fa'
  }
}));

const MainLayout = ({
  children
}) => {
  const classes = useStyles();
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["useHistory"])();
  console.log(history.location);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.root,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 5
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_SocialBar__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TopBar__WEBPACK_IMPORTED_MODULE_4__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: history.location.pathname !== '/' ? {
      display: 'block'
    } : {
      display: 'none'
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: classes.MainLayout,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }
  }, children), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_Footer__WEBPACK_IMPORTED_MODULE_3__["default"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (MainLayout);

/***/ }),

/***/ "./src/layouts/LoginLayout/index.js":
/*!******************************************!*\
  !*** ./src/layouts/LoginLayout/index.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/layouts/LoginLayout/index.js";




const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["makeStyles"])(theme => ({
  content: {
    // height: "100vh",
    overflowX: "auto",
    background: theme.palette.background.dark1,
    [theme.breakpoints.down("sm")]: {
      height: "auto",
      overflow: "unset"
    }
  },
  left: {
    height: "100vh",
    [theme.breakpoints.down("sm")]: {
      height: "auto"
    },
    [theme.breakpoints.down("xs")]: {}
  },
  box: {
    background: theme.palette.background.lightblack,
    //boxShadow: 'rgba(0, 0, 0, 0.15) 2.4px 2.4px 3.2px',
    [theme.breakpoints.down("sm")]: {
      paddingBottom: "50px"
    }
  },
  centro: {
    [theme.breakpoints.down("md")]: {
      display: "none"
    }
  },
  opener: {
    // [theme.breakpoints.down("lg")]: {
    //   display: "none",
    // },
    // [theme.breakpoints.down("md")]: {
    //   display: "none",
    // },
    // [theme.breakpoints.down("sm")]: {
    //   display: "block",
    // },
    // [theme.breakpoints.only("xs")]: {
    //   display: "block",
    // },
    "@media(min-width:1280px)": {
      display: "none"
    }
  },
  headBox: {
    "& .shape1": {
      position: "absolute",
      left: "0px",
      zIndex: "0",
      bottom: "0px ",
      width: "177px",
      [theme.breakpoints.down("md")]: {
        width: "80px"
      },
      [theme.breakpoints.down("sm")]: {
        display: "none"
      }
    },
    "& .shape3": {
      right: "0px",
      width: "157px",
      zIndex: "11111",
      position: "absolute",
      top: "0",
      [theme.breakpoints.down("md")]: {
        top: "-17px",
        width: "80px"
      },
      [theme.breakpoints.down("sm")]: {
        display: "none"
      }
    } // "& .leftShade": {
    //   top: "25%",
    //   left: "10%",
    //   right: "auto",
    //   width: "350px",
    //   bottom: "auto",
    //   filter: "blur(100px)",
    //   height: "350px",
    //   opacity: "0.8",
    //   zIndex: "1",
    //   position: "absolute",
    //   transform: "rotate(45deg)",
    //   borderRadius: "1000px",
    //   background: "#3e6239 !important",
    // },

  },
  logBox: {
    // padding:"150px 20px 0px",
    [theme.breakpoints.down("md")]: {
      padding: "50px 60px"
    },
    [theme.breakpoints.down("sm")]: {
      padding: "60px 40px"
    },
    [theme.breakpoints.down("xs")]: {
      padding: "70px 20px"
    }
  },
  loginBox: {
    background: "url('./images/background.png')",
    height: "100vh",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    "& h1": {
      [theme.breakpoints.down("sm")]: {
        fontSize: "30px"
      }
    }
  },
  gridView: {
    "@media(max-width:600px)": {
      display: "none"
    }
  },
  imgBox: {
    maxWidth: "160px",
    margin: "auto",
    marginBottom: "10px"
  },
  leftImg: {
    marginTop: "20px",
    [theme.breakpoints.down("sm")]: {
      maxWidth: "150px",
      marginTop: "10px"
    }
  },
  PdTp: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  left: {
    height: "100vh",
    [theme.breakpoints.down("md")]: {
      display: "none"
    },
    [theme.breakpoints.down("sm")]: {
      display: "none"
    },
    [theme.breakpoints.down("xs")]: {
      display: "none"
    }
  },
  mainbox: {
    boxShadow: "0px 30px 30px rgba(0, 0, 0, 0.3)",
    backgroundColor: "#302F35",
    backdropFilter: "blur(42px)",
    backgroundImage: "url(/images/background.png)",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat"
  },
  content: {
    // height: "100vh",
    overflowX: "auto",
    background: "#000",
    color: "#fff"
  }
}));

const LoginLayout = ({
  children
}) => {
  const classes = useStyles();
  const history = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["useHistory"])();
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    className: classes.headBox,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 189,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    src: "images/LeftImage.png",
    alt: "Top Left Arrow",
    className: "shape1 moveTop",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 190,
      columnNumber: 9
    }
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    src: "images/RightImage.png",
    alt: "Top Right Arrow",
    className: "shape3 moveLeft",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 195,
      columnNumber: 9
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
    container: true,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 201,
      columnNumber: 7
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
    item: true,
    xs: 12,
    sm: 12,
    md: 12,
    lg: 5,
    className: classes.left,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 202,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    className: classes.mainbox,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 11
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    className: "signupmain",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 210,
      columnNumber: 13
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    display: "flex",
    justifyContent: "center",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 211,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
    variant: "h5",
    style: {
      fontSize: "30px",
      color: "white"
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 212,
      columnNumber: 17
    }
  }, "Welcome Back")), " ", /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    style: {
      cursor: "pointer"
    },
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 219,
      columnNumber: 15
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    src: "/images/logo.png",
    style: {
      width: "250px",
      margin: "20px 0"
    },
    alt: "",
    onClick: () => history.push("/"),
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 225,
      columnNumber: 17
    }
  }))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
    item: true,
    xs: 12,
    sm: 12,
    md: 12,
    lg: 7,
    className: classes.PdTp,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 235,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Container"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 236,
      columnNumber: 9
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    className: classes.logBox,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 237,
      columnNumber: 21
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    className: classes.imgBox,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 238,
      columnNumber: 23
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
    className: classes.opener,
    src: "./images/move2Earn/logo.png",
    alt: "LOGO for MOVE2EARN",
    width: "100%",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 239,
      columnNumber: 25
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Container"], {
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 247,
      columnNumber: 23
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    className: classes.content,
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 248,
      columnNumber: 23
    }
  }, children)))))));
};

LoginLayout.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.node
};
/* harmony default export */ __webpack_exports__["default"] = (LoginLayout);

/***/ }),

/***/ "./src/routes.js":
/*!***********************!*\
  !*** ./src/routes.js ***!
  \***********************/
/*! exports provided: routes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
/* harmony import */ var src_layouts_HomeLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/layouts/HomeLayout */ "./src/layouts/HomeLayout/index.js");
/* harmony import */ var src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/layouts/DashboardLayout */ "./src/layouts/DashboardLayout/index.js");
/* harmony import */ var src_layouts_LoginLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/layouts/LoginLayout */ "./src/layouts/LoginLayout/index.js");
var _jsxFileName = "/Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/routes.js";





const routes = [{
  exact: true,
  path: "/dashboard",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(23)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard */ "./src/views/pages/Dashboard/index.js")))
}, {
  exact: true,
  path: "/users",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(15), __webpack_require__.e(31)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Userlist */ "./src/views/pages/Dashboard/Userlist.js")))
}, {
  exact: true,
  path: "/edit-users",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(19), __webpack_require__.e(60)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/UserEdit */ "./src/views/pages/Dashboard/UserEdit.js")))
}, {
  exact: true,
  path: "/categoryMgmt",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(21)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StackingMgmt/StackingTab */ "./src/views/pages/Dashboard/StackingMgmt/StackingTab.js")))
}, {
  exact: true,
  path: "/contract-sniffed",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(30)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Contract/ContractSniffer */ "./src/views/pages/Dashboard/Contract/ContractSniffer.js")))
}, {
  exact: true,
  path: "/nft-list",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(17), __webpack_require__.e(13)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/User/ViewStake */ "./src/views/pages/Dashboard/User/ViewStake.js")))
}, {
  exact: true,
  path: "/stake",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(17), __webpack_require__.e(7), __webpack_require__.e(12), __webpack_require__.e(13), __webpack_require__.e(33)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/User/Stake */ "./src/views/pages/Dashboard/User/Stake.js")))
}, {
  exact: true,
  path: "/nft-detail",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 57).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/User/NftDetail */ "./src/views/pages/Dashboard/User/NftDetail.js")))
}, {
  exact: true,
  path: "/user-list",
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(5), __webpack_require__.e(58)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/User/UserManagement */ "./src/views/pages/Dashboard/User/UserManagement.js")))
}, {
  exact: true,
  path: "/",
  layout: src_layouts_LoginLayout__WEBPACK_IMPORTED_MODULE_4__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(3), __webpack_require__.e(8), __webpack_require__.e(9), __webpack_require__.e(41)]).then(__webpack_require__.bind(null, /*! src/views/auth/LogIn */ "./src/views/auth/LogIn/index.js")))
}, {
  exact: true,
  path: "/logo",
  layout: src_layouts_LoginLayout__WEBPACK_IMPORTED_MODULE_4__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.resolve(/*! import() */).then(__webpack_require__.bind(null, /*! src/component/Logo */ "./src/component/Logo.js")))
}, {
  exact: true,
  path: "/forget-password",
  // guard:true,
  layout: src_layouts_LoginLayout__WEBPACK_IMPORTED_MODULE_4__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(8), __webpack_require__.e(9), __webpack_require__.e(24)]).then(__webpack_require__.bind(null, /*! src/views/auth/forget-password/index */ "./src/views/auth/forget-password/index.js")))
}, {
  exact: true,
  path: "/instrauctions",
  // guard:true,
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(4), __webpack_require__.e(52)]).then(__webpack_require__.bind(null, /*! src/views/auth/forget-password-link/index */ "./src/views/auth/forget-password-link/index.js")))
}, {
  exact: true,
  path: "/reset-password",
  // guard:true,{n}
  layout: src_layouts_LoginLayout__WEBPACK_IMPORTED_MODULE_4__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(8), __webpack_require__.e(9), __webpack_require__.e(25)]).then(__webpack_require__.bind(null, /*! src/views/auth/reset-password/index */ "./src/views/auth/reset-password/index.js")))
}, {
  exact: true,
  path: "/contentMgmt",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(8), __webpack_require__.e(26), __webpack_require__.e(7), __webpack_require__.e(15), __webpack_require__.e(18), __webpack_require__.e(32)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Admin/Index */ "./src/views/pages/Dashboard/Admin/Index.js")))
}, {
  exact: true,
  path: "/stackingDetail",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(34)]).then(__webpack_require__.bind(null, /*! src/component/StakingDetails */ "./src/component/StakingDetails.js")))
}, {
  exact: true,
  path: "/edit-partner",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(10)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Admin/AddPartner */ "./src/views/pages/Dashboard/Admin/AddPartner.js")))
}, {
  exact: true,
  path: "/view-partner",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(10)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Admin/AddPartner */ "./src/views/pages/Dashboard/Admin/AddPartner.js")))
}, {
  exact: true,
  path: "/pressMedia",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(2), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(18), __webpack_require__.e(22)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Press&Media/index */ "./src/views/pages/Dashboard/Press&Media/index.js")))
}, {
  exact: true,
  path: "/add-media",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(46)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Press&Media/mediaAdd */ "./src/views/pages/Dashboard/Press&Media/mediaAdd.js")))
}, {
  exact: true,
  path: "/view-media",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(45)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Press&Media/ViewMedia.js */ "./src/views/pages/Dashboard/Press&Media/ViewMedia.js")))
}, {
  exact: true,
  path: "/edit-media",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(44)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Press&Media/EditMedia.js */ "./src/views/pages/Dashboard/Press&Media/EditMedia.js")))
}, {
  exact: true,
  path: "/AddPartner",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(10)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/Admin/AddPartner */ "./src/views/pages/Dashboard/Admin/AddPartner.js")))
}, {
  exact: true,
  path: "/ViewUser",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(1), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(5), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(12), __webpack_require__.e(59)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/User/ViewUser */ "./src/views/pages/Dashboard/User/ViewUser.js")))
}, {
  exact: true,
  path: "/resouceMgmt",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(3), __webpack_require__.e(5), __webpack_require__.e(19), __webpack_require__.e(27), __webpack_require__.e(43)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/Static */ "./src/views/pages/Dashboard/StaticManagement/Static.js")))
}, {
  exact: true,
  path: "/team-management",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(14), __webpack_require__.e(56)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/TeamManagement */ "./src/views/pages/Dashboard/StaticManagement/TeamManagement.js")))
}, {
  exact: true,
  path: "/Faq-manage",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(3), __webpack_require__.e(4), __webpack_require__.e(6), __webpack_require__.e(7), __webpack_require__.e(14), __webpack_require__.e(55)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/PrivacyManage */ "./src/views/pages/Dashboard/StaticManagement/PrivacyManage.js")))
}, {
  exact: true,
  path: "/add-team",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(47)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/AddNewTeam */ "./src/views/pages/Dashboard/StaticManagement/AddNewTeam.js")))
}, {
  exact: true,
  path: "/view-team",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(49)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/ViewTeam */ "./src/views/pages/Dashboard/StaticManagement/ViewTeam.js")))
}, {
  exact: true,
  path: "/edit-team",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(0), __webpack_require__.e(2), __webpack_require__.e(48)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/Edit-team.js */ "./src/views/pages/Dashboard/StaticManagement/Edit-team.js")))
}, {
  exact: true,
  path: "/social-links",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(38)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/SocialLinks */ "./src/views/pages/Dashboard/StaticManagement/SocialLinks.js")))
}, {
  exact: true,
  path: "/edit-links",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(39)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/SocialLinksEdit */ "./src/views/pages/Dashboard/StaticManagement/SocialLinksEdit.js")))
}, {
  exact: true,
  path: "/view-content",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 53).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/About */ "./src/views/pages/Dashboard/StaticManagement/About.js")))
}, {
  exact: true,
  path: "/view-announcements",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 54).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/Announcements */ "./src/views/pages/Dashboard/StaticManagement/Announcements.js")))
}, {
  exact: true,
  path: "/edit-announcements",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(36)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/AnnouncementsEdit */ "./src/views/pages/Dashboard/StaticManagement/AnnouncementsEdit.js")))
}, {
  exact: true,
  path: "/edit-content",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(11), __webpack_require__.e(35)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/AboutEdit */ "./src/views/pages/Dashboard/StaticManagement/AboutEdit.js")))
}, {
  exact: true,
  path: "/view-terms",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 16).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/TermsCondition */ "./src/views/pages/Dashboard/StaticManagement/TermsCondition.js")))
}, {
  exact: true,
  path: "/edit-terms",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(11), __webpack_require__.e(40)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/TermsConditionEdit */ "./src/views/pages/Dashboard/StaticManagement/TermsConditionEdit.js")))
}, {
  exact: true,
  path: "/policy",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 50).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/PrivacyPolicy */ "./src/views/pages/Dashboard/StaticManagement/PrivacyPolicy.js")))
}, {
  exact: true,
  path: "/edit-policy",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(11), __webpack_require__.e(37)]).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/PrivacyPolicyEdit */ "./src/views/pages/Dashboard/StaticManagement/PrivacyPolicyEdit.js")))
}, {
  exact: true,
  path: "/view-terms",
  // guard:true,
  layout: src_layouts_DashboardLayout__WEBPACK_IMPORTED_MODULE_3__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 16).then(__webpack_require__.bind(null, /*! src/views/pages/Dashboard/StaticManagement/TermsCondition */ "./src/views/pages/Dashboard/StaticManagement/TermsCondition.js")))
}, {
  exact: true,
  path: "/terms-condition",
  layout: src_layouts_HomeLayout__WEBPACK_IMPORTED_MODULE_2__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(29)]).then(__webpack_require__.bind(null, /*! src/views/pages/TermsAndConditions */ "./src/views/pages/TermsAndConditions/index.js")))
}, {
  exact: true,
  path: "/terms-services",
  layout: src_layouts_HomeLayout__WEBPACK_IMPORTED_MODULE_2__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => __webpack_require__.e(/*! import() */ 51).then(__webpack_require__.bind(null, /*! src/views/pages/TermsAndConditions/TermsServices */ "./src/views/pages/TermsAndConditions/TermsServices.js")))
}, {
  exact: true,
  path: "/privacy-policy",
  layout: src_layouts_HomeLayout__WEBPACK_IMPORTED_MODULE_2__["default"],
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(28)]).then(__webpack_require__.bind(null, /*! src/views/pages/Privacy */ "./src/views/pages/Privacy/index.js")))
}, {
  exact: true,
  path: "/404",
  component: Object(react__WEBPACK_IMPORTED_MODULE_0__["lazy"])(() => Promise.all(/*! import() */[__webpack_require__.e(1), __webpack_require__.e(42)]).then(__webpack_require__.bind(null, /*! src/views/errors/NotFound */ "./src/views/errors/NotFound.js")))
}, {
  component: () => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Redirect"], {
    to: "/404",
    __self: undefined,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 380,
      columnNumber: 22
    }
  })
}];

/***/ }),

/***/ "./src/scss/main.css":
/*!***************************!*\
  !*** ./src/scss/main.css ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./main.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/scss/main.css");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(true) {
	module.hot.accept(/*! !../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./main.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/scss/main.css", function() {
		var newContent = __webpack_require__(/*! !../../node_modules/css-loader/dist/cjs.js??ref--6-oneOf-3-1!../../node_modules/postcss-loader/src??postcss!./main.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/scss/main.css");

		if(typeof newContent === 'string') newContent = [[module.i, newContent, '']];

		var locals = (function(a, b) {
			var key, idx = 0;

			for(key in a) {
				if(!b || a[key] !== b[key]) return false;
				idx++;
			}

			for(key in b) idx--;

			return idx === 0;
		}(content.locals, newContent.locals));

		if(!locals) throw new Error('Aborting CSS HMR due to changed css-modules locals.');

		update(newContent);
	});

	module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ "./src/serviceWorker.js":
/*!******************************!*\
  !*** ./src/serviceWorker.js ***!
  \******************************/
/*! exports provided: register, unregister */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "register", function() { return register; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unregister", function() { return unregister; });
// This optional code is used to register a service worker.
// register() is not called by default.
// This lets the app load faster on subsequent visits in production, and gives
// it offline capabilities. However, it also means that developers (and users)
// will only see deployed updates on subsequent visits to a page, after all the
// existing tabs open on the page have been closed, since previously cached
// resources are updated in the background.
// To learn more about the benefits of this model and instructions on how to
// opt-in, read https://bit.ly/CRA-PWA
const isLocalhost = Boolean(window.location.hostname === 'localhost' || // [::1] is the IPv6 localhost address.
window.location.hostname === '[::1]' || // 127.0.0.0/8 are considered localhost for IPv4.
window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/));
function register(config) {
  if (false) {}
}

function registerValidSW(swUrl, config) {
  navigator.serviceWorker.register(swUrl).then(registration => {
    registration.onupdatefound = () => {
      const installingWorker = registration.installing;

      if (installingWorker == null) {
        return;
      }

      installingWorker.onstatechange = () => {
        if (installingWorker.state === 'installed') {
          if (navigator.serviceWorker.controller) {
            // At this point, the updated precached content has been fetched,
            // but the previous service worker will still serve the older
            // content until all client tabs are closed.
            console.log('New content is available and will be used when all ' + 'tabs for this page are closed. See https://bit.ly/CRA-PWA.'); // Execute callback

            if (config && config.onUpdate) {
              config.onUpdate(registration);
            }
          } else {
            // At this point, everything has been precached.
            // It's the perfect time to display a
            // "Content is cached for offline use." message.
            console.log('Content is cached for offline use.'); // Execute callback

            if (config && config.onSuccess) {
              config.onSuccess(registration);
            }
          }
        }
      };
    };
  }).catch(error => {
    console.error('Error during service worker registration:', error);
  });
}

function checkValidServiceWorker(swUrl, config) {
  // Check if the service worker can be found. If it can't reload the page.
  fetch(swUrl, {
    headers: {
      'Service-Worker': 'script'
    }
  }).then(response => {
    // Ensure service worker exists, and that we really are getting a JS file.
    const contentType = response.headers.get('content-type');

    if (response.status === 404 || contentType != null && contentType.indexOf('javascript') === -1) {
      // No service worker found. Probably a different app. Reload the page.
      navigator.serviceWorker.ready.then(registration => {
        registration.unregister().then(() => {
          window.location.reload();
        });
      });
    } else {
      // Service worker found. Proceed as normal.
      registerValidSW(swUrl, config);
    }
  }).catch(() => {
    console.log('No internet connection found. App is running in offline mode.');
  });
}

function unregister() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then(registration => {
      registration.unregister();
    }).catch(error => {
      console.error(error.message);
    });
  }
}

/***/ }),

/***/ "./src/theme/index.js":
/*!****************************!*\
  !*** ./src/theme/index.js ***!
  \****************************/
/*! exports provided: createTheme */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createTheme", function() { return createTheme; });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "./node_modules/lodash/lodash.js");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "./node_modules/@material-ui/core/esm/index.js");
/* harmony import */ var _shadows__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shadows */ "./src/theme/shadows.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./typography */ "./src/theme/typography.js");




const baseOptions = {
  direction: "ltr",
  typography: _typography__WEBPACK_IMPORTED_MODULE_3__["default"],
  overrides: {
    MuiDialogActions: {
      root: {
        justifyContent: "center"
      }
    },
    MuiDialog: {
      paperScrollPaper: {
        padding: "15px" // border: "1px solid #BEF71E",

      },
      paperWidthSm: {
        maxWidth: "450px",
        background: "#041901",
        border: "1px solid #3f51b566"
      }
    },
    MuiPaper: {
      elevation24: {
        boxShadow: "none"
      }
    },
    MuiBackdrop: {
      root: {
        top: "0",
        left: "0",
        right: "0",
        bottom: "0",
        display: "flex",
        zIndex: "-1",
        position: "fixed",
        background: "transparent",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "transparent",
        WebkitTapHighlightColor: "transparent",
        background: "transparent"
      }
    },
    MuiMenuItem: {
      root: {
        fontSize: "14px"
      }
    },
    MuiPickersToolbar: {
      toolbar: {
        height: "100px",
        display: "flex",
        alignItems: "center",
        flexDirection: "row",
        justifyContent: "center",
        backgroundColor: "green"
      }
    },
    MuiInput: {
      underline: {
        "&:hover": {
          borderBottom: "transparent"
        },
        "&::after": {
          left: "0",
          right: "0",
          bottom: "0",
          content: '""',
          position: "absolute",
          transform: "scaleX(0)",
          transition: "transform 200ms cubic-bezier(0.0, 0, 0.2, 1) 0ms",
          borderBottom: "transparent !important",
          pointerEvents: "none"
        },
        "&::before": {
          left: "0",
          right: "0",
          bottom: "0",
          content: '"\\00a0"',
          position: "absolute",
          transition: "border-bottom-color 200ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
          borderBottom: "transparent !important",
          pointerEvents: "none",
          "&:hover": {
            borderBottom: "transparent"
          }
        }
      }
    },
    MuiFormControl: {
      root: {
        width: "96%"
      },
      marginNormal: {
        marginTop: "7px"
      }
    },
    MuiSvgIcon: {
      root: {
        fontSize: "18px"
      }
    },
    MuiListItem: {
      gutters: {
        paddingLeft: "16px",
        paddingRight: "16px"
      }
    },
    MuiSlider: {
      mark: {
        width: 5,
        height: 5,
        borderRadius: "50%",
        border: "2px solid #fff",
        top: 9,
        backgroundColor: "#222",
        marginLeft: "-2px"
      },
      markActive: {
        width: 5,
        height: 5,
        borderRadius: "50%",
        border: "2px solid #EAB73B",
        top: 9,
        backgroundColor: "#EAB73B",
        marginLeft: "-2px"
      }
    },
    MuiButton: {
      containedSecondary: {
        background: "transparent !important",
        border: "1px solid #1EB808",
        fontFamily: "'Sen', sans-serif",
        color: "#ffff",
        height: "43px",
        padding: "10px 33px !important",
        fontSize: "14px !important",
        lineHeight: "21px",
        // marginRight: "10px",
        borderRadius: "5px",
        fontWeight: "600",
        "&:hover": {
          background: "#1EB808 !important",
          color: "#FFFFFF"
        }
      },
      containedPrimary: {
        color: "#ffff",
        height: "43px",
        padding: "10px 33px",
        fontSize: "15px !important",
        boxShadow: "0px 4px 4px rgb(0 0 0 / 25%)",
        lineHeight: "21px",
        borderRadius: "5px",
        fontFamily: "'Sen', sans-serif",
        background: "#1EB808 !important",
        border: "1px solid #1EB808",
        fontWeight: "600",
        "&:hover": {
          background: "transparent !important",
          border: "1px solid #1EB808",
          color: "#FFFFFF"
        }
      },
      contained: {
        color: "white",
        fontWeight: 500,
        padding: "5px 5px",
        backgroundColor: "",
        color: "#fff",
        fontFamily: "'Saira Semi Condensed', sans-serif",
        "&.Mui-disabled": {
          backgroundColor: "#7e7e7e70 !important",
          color: "#fff !important"
        }
      },
      outlinedPrimary: {
        borderRadius: "50px",
        color: "#300760",
        fontWeight: 600,
        background: "red",
        padding: "5px 19px",
        border: "2px solid #300760",
        "&:hover": {
          backgroundColor: "#f30065",
          border: "2px solid #f30065",
          color: "#fff"
        }
      },
      outlinedSizeSmall: {
        padding: "6px 23px",
        fontSize: "16px",
        lineHeight: " 24px"
      },
      root: {
        "&.Mui-disabled": {
          color: "#fff9 !important"
        }
      },
      text: {
        fontFamily: "'Saira Semi Condensed', sans-serif"
      }
    },
    MuiList: {
      padding: {
        paddingTop: "0px",
        paddingBottom: "0px"
      }
    },
    MuiFormHelperText: {
      root: {
        marginTop: "1px"
      }
    },
    MuiRadio: {
      root: {
        color: "#C0BBBB"
      },
      colorSecondary: {
        "&$checked": {
          color: "#EAB73B"
        }
      }
    },
    MuiTableCell: {
      root: {
        borderBottom: "1px solid #1eb80857",
        fontSize: "14px",
        fontWeight: "300"
      },
      head: {
        color: "#AAAAAA",
        fontWeight: "500 !important"
      }
    },
    MuiSelect: {
      selectMenu: {
        height: "none"
      },
      outlined: {
        "&.MuiSelect-outlined": {
          fontSize: "13px"
        }
      },
      icon: {
        color: "rgb(30 184 8)"
      }
    },
    MuiStep: {
      alternativeLabel: {
        marginBottom: "65px"
      }
    },
    MuiStepLabel: {
      root: {
        "&.MuiStepLabel-alternativeLabel": {
          flexDirection: "row"
        }
      },
      label: {
        "&.MuiStepLabel-alternativeLabel": {
          marginTop: "0px",
          marginLeft: "10px",
          fontSize: "14px",
          textAlign: "left"
        },
        "&.MuiStepLabel-completed": {
          color: "#EAB73B"
        },
        "&.MuiStepLabel-active": {
          color: "#EAB73B"
        }
      }
    },
    MuiIconButton: {
      root: {
        color: "#fff"
      },
      edgeEnd: {
        marginRight: "0px"
      }
    },
    MuiTableCell: {
      root: {
        padding: "13px"
      },
      head: {
        lineHeight: "1.5rem"
      }
    }
  }
};
const themesOptions = [{
  name: "LIGHT",
  overrides: {},
  typography: {
    fontFamily: "'Poppins', sans-serif"
  },
  palette: {
    type: "light",
    action: {
      active: _material_ui_core__WEBPACK_IMPORTED_MODULE_1__["colors"].blueGrey[600]
    },
    background: {
      default: "#fff",
      white: "#000",
      light: "#C8FF00",
      blue: "#dfdfdf",
      dark: "#f5f5f5",
      paper: "#cfcccc",
      yellow: "#cc9c28",
      darkgrey: "#f8f7f7",
      wrapper: "#f5f5f5",
      black: "#fff",
      tabbed: "#cfcccc"
    },
    primary: {
      main: "#000000",
      blueMain: "#5D29FF",
      versa: "#fff",
      white: "#fff",
      dull: "#474444",
      recommended: "#000"
    },
    secondary: {
      main: "#000"
    },
    white: {
      main: "#000",
      dullWhite: "#ececec"
    },
    text: {
      primary: _material_ui_core__WEBPACK_IMPORTED_MODULE_1__["colors"].blueGrey[900],
      secondary: _material_ui_core__WEBPACK_IMPORTED_MODULE_1__["colors"].blueGrey[600],
      white: _material_ui_core__WEBPACK_IMPORTED_MODULE_1__["colors"].blueGrey[600]
    }
  },
  shadows: _shadows__WEBPACK_IMPORTED_MODULE_2__["softShadows"]
}, {
  name: "DARK",
  overrides: {
    MuiTableBody: {
      root: {
        background: "#0D1826"
      }
    },
    MuiOutlinedInput: {
      input: {
        padding: "13.5px 14px",
        borderRadius: "10px",
        "&:-webkit-autofill": {
          "-webkit-background-clip": "text !important",
          // transitionDelay: "9999s",
          "caret-color": "transparent",
          "-webkit-box-shadow": "0 0 0 100px transparent inset",
          "-webkit-text-fill-color": "#ffffff78"
        },
        "&:-internal-autofill-selected": {
          color: "#fff"
        }
      },
      notchedOutline: {
        borderColor: "rgb(30 184 8)"
      }
    },
    MuiInputBase: {
      root: {
        // backgroundColor: " #1E1E1E",
        color: "#fff" // border: "1px solid black",

      },
      input: {
        fontSize: "13px",
        fontWeight: "400",
        "&::placeholder": {
          opacity: 1,
          color: "#a1a1a1"
        }
      },
      multiline: {
        // backgroundColor: "#1E1E1E",
        border: "none",
        borderRadius: "10px"
      }
    }
  },
  typography: {
    fontFamily: "'Poppins', sans-serif"
  },
  palette: {
    type: "dark",
    action: {
      active: "rgba(255, 255, 255, 0.54)",
      hover: "rgba(255, 255, 255, 0.04)",
      selected: "rgba(255, 255, 255, 0.08)",
      disabled: "rgba(255, 255, 255, 0.26)",
      disabledBackground: "rgba(255, 255, 255, 0.12)",
      focus: "rgba(255, 255, 255, 0.12)"
    },
    background: {
      default: "#141516",
      white: "#fff",
      light: "#C8FF00",
      blue: "#141516",
      dark: "#222",
      paper: "#111010",
      yellow: "#EAB73B",
      black: "#000",
      wrapper: "#000",
      greyWhite: "#9A9A9A",
      darkgrey: "#1E1E1E",
      btnbg: "#2E2D2D",
      tabbed: "#1C1C1C"
    },
    primary: {
      main: "#fff",
      versa: "#222",
      white: "#fff",
      dull: "#939393",
      recommended: "#9A9A9A"
    },
    secondary: {
      main: "#000"
    },
    white: {
      main: "#000",
      dullWhite: "#383636"
    },
    text: {
      primary: "#fff",
      secondary: "#adb0bb"
    }
  },
  shadows: _shadows__WEBPACK_IMPORTED_MODULE_2__["strongShadows"]
}];
const createTheme = (config = {}) => {
  let themeOptions = themesOptions.find(theme => theme.name === config.theme);

  if (!themeOptions) {
    console.warn(new Error(`The theme ${config.theme} is not valid`));
    [themeOptions] = themesOptions;
  }

  let theme = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["createMuiTheme"])(lodash__WEBPACK_IMPORTED_MODULE_0___default.a.merge({}, baseOptions, themeOptions, {
    direction: config.direction
  }));

  if (config.responsiveFontSizes) {
    theme = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["responsiveFontSizes"])(theme);
  }

  return theme;
};

/***/ }),

/***/ "./src/theme/shadows.js":
/*!******************************!*\
  !*** ./src/theme/shadows.js ***!
  \******************************/
/*! exports provided: softShadows, strongShadows */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "softShadows", function() { return softShadows; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "strongShadows", function() { return strongShadows; });
const softShadows = ['none', '0 0 0 1px rgba(63,63,68,0.05), 0 1px 2px 0 rgba(63,63,68,0.15)', '0 0 1px 0 rgba(0,0,0,0.31), 0 2px 2px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 3px 4px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 4px 6px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 4px 8px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 5px 8px -2px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 6px 12px -4px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 7px 12px -4px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 6px 16px -4px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 7px 16px -4px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 8px 18px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 9px 18px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 10px 20px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 11px 20px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 12px 22px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 13px 22px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 14px 24px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 16px 28px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 18px 30px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 20px 32px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 22px 34px -8px rgba(0,0,0,0.25)', '0 0 1px 0 rgba(0,0,0,0.31), 0 24px 36px -8px rgba(0,0,0,0.25)'];
const strongShadows = ['none', '0 0 1px 0 rgba(0,0,0,0.70), 0 3px 4px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 2px 2px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 3px 4px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 3px 4px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 4px 6px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 4px 6px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 4px 8px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 5px 8px -2px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 6px 12px -4px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 7px 12px -4px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 6px 16px -4px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 7px 16px -4px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 8px 18px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 9px 18px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 10px 20px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 11px 20px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 12px 22px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 13px 22px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 14px 24px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 16px 28px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 18px 30px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 20px 32px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 22px 34px -8px rgba(0,0,0,0.50)', '0 0 1px 0 rgba(0,0,0,0.70), 0 24px 36px -8px rgba(0,0,0,0.50)'];

/***/ }),

/***/ "./src/theme/typography.js":
/*!*********************************!*\
  !*** ./src/theme/typography.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  h1: {
    fontWeight: 500,
    fontSize: 35,
    fontFamily: "'Saira Semi Condensed', sans-serif",
    color: "#fff",
    "@media(max-width:767px)": {
      fontSize: "20px"
    }
  },
  h2: {
    fontWeight: 500,
    fontSize: 30,
    fontFamily: "'Saira Semi Condensed', sans-serif"
  },
  h3: {
    fontWeight: 500,
    fontSize: 25,
    fontFamily: "'Saira Semi Condensed', sans-serif",
    color: "#fff"
  },
  h4: {
    fontWeight: 500,
    fontSize: 20,
    fontFamily: "'Saira Semi Condensed', sans-serif"
  },
  h5: {
    fontWeight: 500,
    fontSize: 18,
    fontFamily: "'Saira Semi Condensed', sans-serif"
  },
  h6: {
    fontWeight: 500,
    fontSize: 16,
    fontFamily: "'Saira Semi Condensed', sans-serif"
  },
  overline: {
    fontWeight: 500
  },
  button: {
    textTransform: "capitalize",
    borderRadius: 27,
    fontFamily: "'Saira Semi Condensed', sans-serif"
  },
  body1: {
    fontSize: 16,
    color: "#fff",
    fontFamily: "'Saira Semi Condensed', sans-serif"
  },
  body2: {
    fontSize: 14,
    fontWeight: "300",
    color: "#fff",
    lineHeight: "21px",
    fontFamily: "'Saira Semi Condensed', sans-serif"
  }
});

/***/ }),

/***/ 1:
/*!**************************************************************************************************************!*\
  !*** multi (webpack)/hot/dev-server.js ./node_modules/react-dev-utils/webpackHotDevClient.js ./src/index.js ***!
  \**************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! /Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/node_modules/webpack/hot/dev-server.js */"./node_modules/webpack/hot/dev-server.js");
__webpack_require__(/*! /Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/node_modules/react-dev-utils/webpackHotDevClient.js */"./node_modules/react-dev-utils/webpackHotDevClient.js");
module.exports = __webpack_require__(/*! /Users/admin/Desktop/move2earn-shabuddin-21054003-reactjs-admin/src/index.js */"./src/index.js");


/***/ }),

/***/ 2:
/*!************************!*\
  !*** buffer (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[1,"runtime-main",61]]]);
//# sourceMappingURL=main.chunk.js.map