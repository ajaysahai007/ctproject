import React from 'react';

import Tokentable1 from './Tokentable1';

export default function index() {
  return <div><Tokentable1/>

    
  </div>;
}
