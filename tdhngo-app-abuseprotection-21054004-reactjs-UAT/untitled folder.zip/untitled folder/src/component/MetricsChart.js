import React,{useState} from "react";
import {
  Box,
  Container,
  Typography,
  makeStyles,
  Button,
  Grid,
  Paper,
  MenuItem,
  Select,
  FormControl
} from "@material-ui/core";
import Chart from "react-apexcharts";
import { Link } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  selectbox:{
    padding:'20px 40px',
    "& h6":{
      marginBottom:'5px',
    }
  }
}));

export default function MetricsChart() {
  const classes = useStyles();
  const [currentvalue,setCurrentValue]=useState("Select");
  const options = {
    series: [
      {
        name: "Desktops",
        data: [2010, 2015, 2012, 2022, 2018, 2020, 2022, 2023, 2012, 2016, 2018, 2011 ],
      },
    ],
    options: {
      chart: {
        height: 300,
        type: "line",
        zoom: {
          enabled: false,
        },
        categories: {
          color: "#fff",
          fontSize: "15px !important",
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: "straight",
      },
     
      fill: {
        colors: ["#F44336", "#E91E63", "#9C27B0"],
      },
      grid: {
        row: {
          colors: ["#fff", "transparent"], // takes an array which will be repeated on columns
          opacity: 0.5,
        },
      },
      xaxis: {
        categories: [
          " January",
          " February ",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
          "November",
          "December",
        ],
      },
      noData: {
        text: "Loading...",
      },
    },
  };

  return (
    <Box className={classes.mainBox}>
      <Paper style={{ paddingTop: "16px" }}>
       <Box className={classes.selectbox}>
       <Typography variant="h6">Time Period</Typography>
        <FormControl variant="outlined" >
          <Box>
            <Select
              name="token"
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              onChange={(e) => setCurrentValue(e.target.value)}
              value={currentvalue}
              style={{ width: "20%" }}
            >
              <MenuItem value="Select">Select</MenuItem>
              <MenuItem value="Today">Today</MenuItem>
              <MenuItem value="Weekly">Weekly</MenuItem>
              <MenuItem value="Monthly">Monthly</MenuItem>
            </Select>
          </Box>
        </FormControl>
       </Box>
        <Chart
          options={options.options}
          series={options.series}
          type="line"
          height={300}
        />
      </Paper>
    </Box>
  );
}
