// import "./styles.css";

import React from "react";
import { useTheme } from "@material-ui/core/styles";
import ReactApexChart from "react-apexcharts";
import { ApexOptions } from "apexcharts";
import { Paper } from "@material-ui/core";
import { blue, yellow, red } from "@material-ui/core/colors";



// const EditRoleForm = ({ onCompleted, onCancel, value, ...rest }: EditRoleFormProps) => {

const TravelDetailsView = () => {
  const theme = useTheme();

  const chartData: ApexOptions = {
    chart: {
      id: "apexchart-example",
      foreColor: theme.palette.primary.main,
      type: "bar"
    },
    xaxis: {
      categories: ["Mental health", "Menstrual health", "Personal Safety", "Support Service"]
    },
    fill: {
      type: "gradient",
      gradient: {
        shade: "light",
        type: "bar",
        shadeIntensity: 0.5,
        gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
        inverseColors: true,
        opacityFrom: 1,
        opacityTo: 1,
        fill: [red, blue, yellow],
        stops: [0, 50, 100]
        // colorStops: []
      }
    },
    series: {
      colors: ['#1A73E8', '#B32824']
    },
    legend: {
      // position: '',
      width: 400
      // position: 'top',
    },
    series: [
      {
        name: "Distance Traveled",
        type: "bar",

        data: [440, 505, 414, 571]
      },
      {
        name: "Time Traveled",
        type: "bar",
        // data: [0, 0, 0, 0]
      }
    ]
  };

  return <ReactApexChart options={chartData} series={chartData.series} />;
};

const Bargraph = () => {
  return (
    <Paper className="barcharback">
      <TravelDetailsView />
    </Paper>
  );
};

export default Bargraph;
